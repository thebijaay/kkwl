/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        km: {
          red: '#C0392B', dred: '#922B21',
          blue: '#1A5276', dblue: '#154360',
          gold: '#D4AC0D', green: '#1E8449',
        },
      },
    },
  },
  plugins: [],
};

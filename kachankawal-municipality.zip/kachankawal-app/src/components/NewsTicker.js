'use client';
import { TICKER_MESSAGES } from '@/lib/data';
export default function NewsTicker() {
  return (
    <div className="py-1.5 overflow-hidden" style={{ background: '#1A5276', color: '#fff' }}>
      <div className="max-w-6xl mx-auto px-4 flex items-center gap-3">
        <span className="text-xs font-bold px-2 py-0.5 rounded flex-shrink-0" style={{ background: '#D4AC0D', color: '#000' }}>
          सूचना
        </span>
        <div className="overflow-hidden flex-1 relative" style={{ height: '1.4rem' }}>
          <div className="ticker-animate text-sm absolute">
            {TICKER_MESSAGES.map((m, i) => <span key={i} className="mr-16">{m}</span>)}
          </div>
        </div>
      </div>
    </div>
  );
}

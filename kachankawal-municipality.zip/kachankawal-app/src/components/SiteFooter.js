import Link from 'next/link';
import { MUNI_INFO } from '@/lib/data';

export default function SiteFooter() {
  return (
    <footer style={{ background: '#154360' }} className="text-gray-300 mt-8">
      <div className="max-w-6xl mx-auto px-4 py-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-4xl">🏡</span>
            <div>
              <div className="text-white font-bold text-lg" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>
                {MUNI_INFO.nameNepali}
              </div>
              <div className="text-blue-300 text-sm">{MUNI_INFO.officeNepali}</div>
            </div>
          </div>
          <p className="text-sm leading-relaxed text-blue-200 mb-3 italic">"{MUNI_INFO.tagline}"</p>
          <div className="text-sm space-y-1 text-blue-200">
            <div>📞 {MUNI_INFO.phone}</div>
            <div>📧 {MUNI_INFO.email}</div>
            <div>📍 {MUNI_INFO.address}</div>
          </div>
          <div className="mt-4 flex gap-2">
            <a href={MUNI_INFO.socialMedia.facebook} target="_blank" rel="noreferrer"
              className="bg-white/10 hover:bg-white/20 text-white text-xs px-3 py-1 rounded transition-colors">Facebook</a>
            <a href={MUNI_INFO.socialMedia.twitter} target="_blank" rel="noreferrer"
              className="bg-white/10 hover:bg-white/20 text-white text-xs px-3 py-1 rounded transition-colors">Twitter</a>
          </div>
        </div>

        <div>
          <h5 className="text-white font-bold mb-3 pb-2 border-b border-white/20">त्वरित सेवाहरू</h5>
          <ul className="space-y-2 text-sm">
            {['घटना दर्ता', 'नागरिकता सिफारिस', 'सामाजिक सुरक्षा', 'व्यवसाय दर्ता', 'निर्माण अनुमति', 'गुनासो दर्ता'].map(s => (
              <li key={s}><Link href="/services" className="text-blue-200 hover:text-white transition-colors">{s}</Link></li>
            ))}
            <li><Link href="/dashboard" className="text-yellow-300 hover:text-white font-semibold transition-colors">🔐 Online Request Portal</Link></li>
          </ul>
        </div>

        <div>
          <h5 className="text-white font-bold mb-3 pb-2 border-b border-white/20">महत्वपूर्ण लिंकहरू</h5>
          <ul className="space-y-2 text-sm">
            {[
              { l: 'परिचय', h: '/about' }, { l: 'वडा कार्यालयहरू', h: '/wards' },
              { l: 'सूचना / समाचार', h: '/notices' }, { l: 'बोलपत्र सूचना', h: '/notices#tenders' },
              { l: 'डाउनलोड / फारम', h: '/downloads' }, { l: 'सम्पर्क', h: '/contact' },
            ].map(({ l, h }) => (
              <li key={l}><Link href={h} className="text-blue-200 hover:text-white transition-colors">{l}</Link></li>
            ))}
          </ul>
          <h5 className="text-white font-bold mt-5 mb-3 pb-2 border-b border-white/20">प्रमुख सम्पर्क</h5>
          <ul className="space-y-1 text-xs text-blue-200">
            <li>अध्यक्ष: {MUNI_INFO.chairman.phone}</li>
            <li>उपाध्यक्ष: {MUNI_INFO.viceChairman.phone}</li>
            <li>CAO: {MUNI_INFO.chiefAdminOfficer.phone}</li>
            <li>सूचना अधिकारी: {MUNI_INFO.infoOfficerPhone}</li>
          </ul>
        </div>
      </div>
      <div style={{ background: '#0d2a40' }} className="text-center py-3 text-xs text-blue-300">
        © {new Date().getFullYear()} {MUNI_INFO.nameNepali} — All Rights Reserved | {MUNI_INFO.district}, {MUNI_INFO.province}, Nepal
        &nbsp;|&nbsp;
        <Link href="/login" className="hover:text-white">Admin Login</Link>
      </div>
    </footer>
  );
}

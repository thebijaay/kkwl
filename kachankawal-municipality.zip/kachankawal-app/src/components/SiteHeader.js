'use client';
import Link from 'next/link';
import { MUNI_INFO } from '@/lib/data';

export default function SiteHeader() {
  return (
    <>
      {/* Top bar */}
      <div className="text-xs py-1.5" style={{ background: '#154360', color: '#fff' }}>
        <div className="max-w-6xl mx-auto px-4 flex flex-wrap justify-between items-center gap-1">
          <span>🇳🇵 Federal Democratic Republic of Nepal &nbsp;|&nbsp; {MUNI_INFO.province} &nbsp;|&nbsp; {MUNI_INFO.district}</span>
          <div className="flex items-center gap-3 flex-wrap">
            <a href={`tel:${MUNI_INFO.phone}`} className="text-blue-200 hover:text-white transition-colors">📞 {MUNI_INFO.phone}</a>
            <a href={`mailto:${MUNI_INFO.email}`} className="text-blue-200 hover:text-white transition-colors hidden sm:inline">📧 {MUNI_INFO.email}</a>
            <Link href="/login" className="text-xs font-bold px-2 py-0.5 rounded transition-colors hover:bg-white/20" style={{ border: '1px solid rgba(255,255,255,0.4)', color: '#fff' }}>
              🔐 Login
            </Link>
          </div>
        </div>
      </div>

      {/* Main header */}
      <header className="bg-white shadow-md border-b-4" style={{ borderColor: '#C0392B' }}>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-4 flex-wrap">
          {/* Emblem */}
          <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl flex-shrink-0 border-2"
            style={{ background: 'linear-gradient(135deg,#1A5276,#154360)', borderColor: '#D4AC0D' }}>
            🏡
          </div>

          {/* Titles */}
          <div className="flex-1 min-w-0">
            <h1 className="font-bold leading-tight" style={{ color: '#154360', fontSize: '1.4rem', fontFamily: 'Noto Sans Devanagari, sans-serif' }}>
              {MUNI_INFO.nameNepali}
            </h1>
            <p className="font-semibold text-sm" style={{ color: '#C0392B' }}>{MUNI_INFO.officeNepali}</p>
            <p className="text-xs text-gray-500">{MUNI_INFO.province} — {MUNI_INFO.district}, {MUNI_INFO.country}</p>
          </div>

          {/* Right info */}
          <div className="hidden lg:block text-right text-xs text-gray-500 leading-6">
            <div><strong className="text-blue-900">Kachankawal Rural Municipality</strong></div>
            <div>📞 {MUNI_INFO.phone}</div>
            <div>📧 {MUNI_INFO.email}</div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <Link href="/login"
              className="text-white text-xs font-bold px-3 py-2 rounded transition-opacity hover:opacity-80"
              style={{ background: '#C0392B' }}>
              🔐 Login
            </Link>
            <Link href="/register"
              className="text-xs font-bold px-3 py-2 rounded border transition-colors hover:text-white"
              style={{ color: '#1A5276', borderColor: '#1A5276' }}
              onMouseEnter={e => { e.target.style.background='#1A5276'; e.target.style.color='#fff'; }}
              onMouseLeave={e => { e.target.style.background=''; e.target.style.color='#1A5276'; }}>
              📝 Register
            </Link>
          </div>
        </div>
      </header>
    </>
  );
}

'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

const SLIDES = [
  { bg: 'linear-gradient(135deg,#0d2a40,#1a5276)', title: 'कचनकवल गाउँपालिका', sub: 'Kachankawal Rural Municipality', desc: 'झापा जिल्ला, कोशी प्रदेश — ७ वडाका नागरिकहरूलाई पारदर्शी र प्रभावकारी सेवा प्रदान गर्न प्रतिबद्ध।', btn: 'सेवाहरू हेर्नुहोस् →', href: '/services', emoji: '🏡' },
  { bg: 'linear-gradient(135deg,#7b2020,#c0392b)', title: 'डिजिटल सेवा केन्द्र', sub: 'Digital Service Centre', desc: 'अनलाइन सेवा आवेदन, घटना दर्ता, सामाजिक सुरक्षा र अन्य सेवाहरू अब डिजिटल माध्यमबाट उपलब्ध।', btn: 'Online Portal →', href: '/dashboard', emoji: '💻' },
  { bg: 'linear-gradient(135deg,#145a32,#1e8449)', title: 'कृषि तथा उत्पादन', sub: 'Agriculture & Production', desc: 'कृषि प्रविधि, सिँचाइ, अनुदान र प्राङ्गारिक खेतीको माध्यमबाट समृद्ध कचनकवल निर्माण।', btn: 'थप जान्नुहोस् →', href: '/about', emoji: '🌾' },
];

export default function HeroSlider() {
  const [cur, setCur] = useState(0);
  useEffect(() => { const t = setInterval(() => setCur(c => (c + 1) % SLIDES.length), 5000); return () => clearInterval(t); }, []);
  const s = SLIDES[cur];
  return (
    <div className="relative overflow-hidden" style={{ height: '380px' }}>
      <div className="absolute inset-0 transition-all duration-700" style={{ background: s.bg }} />
      <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.25)' }} />
      <div className="relative z-10 max-w-6xl mx-auto px-4 h-full flex items-center">
        <div className="text-white fade-up" key={cur}>
          <div className="text-5xl mb-3">{s.emoji}</div>
          <p className="text-sm font-semibold mb-1 opacity-80">{s.sub}</p>
          <h2 className="font-bold mb-3" style={{ fontSize: '2.2rem', fontFamily: 'Noto Sans Devanagari, sans-serif', textShadow: '1px 1px 4px rgba(0,0,0,.5)', lineHeight: 1.2 }}>{s.title}</h2>
          <p className="opacity-90 max-w-xl mb-5 text-sm leading-relaxed">{s.desc}</p>
          <Link href={s.href} className="inline-block text-white font-bold px-6 py-2.5 rounded text-sm transition-all hover:opacity-90" style={{ background: 'rgba(255,255,255,0.2)', border: '2px solid rgba(255,255,255,0.6)' }}>{s.btn}</Link>
        </div>
      </div>
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {SLIDES.map((_, i) => (
          <button key={i} onClick={() => setCur(i)} className={`w-2.5 h-2.5 rounded-full transition-all ${i === cur ? 'bg-white scale-125' : 'bg-white/40'}`} />
        ))}
      </div>
    </div>
  );
}

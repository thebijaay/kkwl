'use client';
import { usePathname } from 'next/navigation';
import SiteHeader from './SiteHeader';
import SiteNav from './SiteNav';
import NewsTicker from './NewsTicker';
import SiteFooter from './SiteFooter';

// Admin and dashboard pages use their own layouts
const SKIP_SHELL = ['/admin', '/dashboard', '/login', '/register'];

export default function PublicLayout({ children }) {
  const pathname = usePathname();
  const skip = SKIP_SHELL.some(p => pathname.startsWith(p));

  if (skip) return <>{children}</>;

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <SiteNav />
      <NewsTicker />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}

'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const NAV = [
  { label: 'गृहपृष्ठ', href: '/' },
  { label: 'परिचय ▾', children: [
    { label: 'संक्षिप्त परिचय', href: '/about' },
    { label: 'संगठनात्मक स्वरुप', href: '/about#org' },
    { label: 'जन प्रतिनिधि', href: '/about#elected' },
    { label: 'Chairman Profile', href: '/about#chairman' },
    { label: 'Vice Chairman', href: '/about#vicechairman' },
    { label: 'कर्मचारी विवरण', href: '/about#staff' },
  ]},
  { label: 'वडा कार्यालय ▾', children: [
    { label: 'सबै वडाहरू', href: '/wards' },
    { label: '१ नं. वडा', href: '/wards/1' },
    { label: '२ नं. वडा', href: '/wards/2' },
    { label: '३ नं. वडा', href: '/wards/3' },
    { label: '४ नं. वडा', href: '/wards/4' },
    { label: '५ नं. वडा', href: '/wards/5' },
    { label: '६ नं. वडा', href: '/wards/6' },
    { label: '७ नं. वडा', href: '/wards/7' },
  ]},
  { label: 'सेवाहरू ▾', children: [
    { label: 'सम्पूर्ण सेवाहरू', href: '/services' },
    { label: 'घटना दर्ता', href: '/services#vital' },
    { label: 'सामाजिक सुरक्षा', href: '/services#social' },
    { label: 'नागरिक वडापत्र', href: '/services#charter' },
    { label: 'नमुना फारमहरु', href: '/downloads' },
    { label: '🔐 Online Service Request', href: '/dashboard' },
  ]},
  { label: 'सूचना तथा जानकारी ▾', children: [
    { label: 'सूचना तथा समाचार', href: '/notices' },
    { label: 'बोलपत्र सूचना', href: '/notices#tenders' },
    { label: 'निर्णयहरु', href: '/notices#decisions' },
    { label: 'स्थानीय राजपत्र', href: '/notices#gazette' },
  ]},
  { label: 'प्रतिवेदन ▾', children: [
    { label: 'मासिक प्रगति प्रतिवेदन', href: '/downloads#monthly' },
    { label: 'वार्षिक प्रगति प्रतिवेदन', href: '/downloads#annual' },
    { label: 'लेखा परीक्षण', href: '/downloads#audit' },
    { label: 'बजेट तथा कार्यक्रम', href: '/downloads#budget' },
    { label: 'आय व्यय विवरण', href: '/downloads#finance' },
  ]},
  { label: 'डाउनलोड', href: '/downloads' },
  { label: 'सम्पर्क', href: '/contact' },
];

export default function SiteNav() {
  const pathname = usePathname();
  return (
    <nav style={{ background: '#C0392B' }}>
      <div className="max-w-6xl mx-auto px-4 flex flex-wrap">
        {NAV.map((item) =>
          item.children ? (
            <div key={item.label} className="nav-dropdown">
              <span className="text-white font-semibold px-3 py-2.5 text-sm cursor-default block hover:bg-red-900 transition-colors select-none">
                {item.label}
              </span>
              <div className="dropdown-menu">
                {item.children.map(c => (
                  <Link key={c.href} href={c.href}
                    className="block px-4 py-2 text-sm text-gray-800 border-b border-gray-100 hover:bg-red-50 hover:text-red-700 transition-colors">
                    {c.label}
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <Link key={item.href} href={item.href}
              className={`text-white font-semibold px-3 py-2.5 text-sm block transition-colors ${pathname === item.href ? 'bg-red-900' : 'hover:bg-red-800'}`}>
              {item.label}
            </Link>
          )
        )}
      </div>
    </nav>
  );
}

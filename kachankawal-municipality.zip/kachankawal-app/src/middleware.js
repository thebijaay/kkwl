// src/middleware.js — Route protection
import { NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';

export async function middleware(request) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get('kmc_token')?.value;
  const payload = token ? await verifyToken(token) : null;

  // Protect /admin routes — admin only
  if (pathname.startsWith('/admin')) {
    if (!payload || payload.role !== 'admin') {
      return NextResponse.redirect(new URL('/login?redirect=/admin', request.url));
    }
  }

  // Protect /dashboard routes — logged-in users
  if (pathname.startsWith('/dashboard')) {
    if (!payload) {
      return NextResponse.redirect(new URL('/login?redirect=/dashboard', request.url));
    }
    if (payload.role === 'admin') {
      return NextResponse.redirect(new URL('/admin', request.url));
    }
  }

  // Redirect logged-in users away from login/register
  if ((pathname === '/login' || pathname === '/register') && payload) {
    return NextResponse.redirect(
      new URL(payload.role === 'admin' ? '/admin' : '/dashboard', request.url)
    );
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*', '/dashboard/:path*', '/login', '/register'],
};

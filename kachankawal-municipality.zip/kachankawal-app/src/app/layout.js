import './globals.css';
import PublicLayout from '@/components/PublicLayout';

export const metadata = {
  title: 'कचनकवल गाउँपालिका | Kachankawal Rural Municipality',
  description: 'Official website of Kachankawal Rural Municipality, Jhapa, Koshi Province, Nepal.',
  keywords: 'Kachankawal, Rural Municipality, Gaun Palika, Jhapa, Koshi Province, Nepal Government',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ne">
      <body>
        <PublicLayout>{children}</PublicLayout>
      </body>
    </html>
  );
}

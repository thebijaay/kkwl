'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { MUNI_INFO, WARDS } from '@/lib/data';

export default function RegisterPage() {
  const router = useRouter();
  const [step, setStep] = useState('form'); // 'form' | 'otp' | 'done'
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', confirm: '', ward: '' });
  const [otp, setOtp] = useState('');
  const [devOtp, setDevOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState('');

  async function handleRegister(e) {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) { setError('Passwords do not match'); return; }
    if (form.password.length < 8) { setError('Password must be at least 8 characters'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName: form.fullName, email: form.email, phone: form.phone, password: form.password, ward: form.ward }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Registration failed'); return; }
      setDevOtp(data.otp || '');
      setStep('otp');
      setMsg(data.message || 'OTP sent to your email.');
    } catch { setError('Network error.'); }
    finally { setLoading(false); }
  }

  async function handleVerify(e) {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, otp }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Verification failed'); return; }
      setStep('done');
      setMsg(data.message);
    } catch { setError('Network error.'); }
    finally { setLoading(false); }
  }

  async function handleResend() {
    setError(''); setLoading(true);
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, action: 'resend' }),
      });
      const data = await res.json();
      if (data.otp) setDevOtp(data.otp);
      setMsg('OTP resent successfully.');
    } catch { setError('Network error.'); }
    finally { setLoading(false); }
  }

  const inp = "w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-200";

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg,#0d2a40,#1a5276)' }}>
      <div className="text-xs py-1.5 text-center text-blue-200" style={{ background: '#0d2a40' }}>
        🇳🇵 Federal Democratic Republic of Nepal &nbsp;|&nbsp; {MUNI_INFO.province}
      </div>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-lg">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center text-3xl border-2"
              style={{ background: 'rgba(255,255,255,0.1)', borderColor: '#D4AC0D' }}>🏡</div>
            <h1 className="text-xl font-bold text-white" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{MUNI_INFO.nameNepali}</h1>
            <p className="text-blue-300 text-sm">Citizen Portal — Register</p>
          </div>

          <div className="bg-white rounded-xl shadow-2xl p-8">
            {/* Steps indicator */}
            <div className="flex items-center justify-center gap-2 mb-6">
              {['Registration', 'OTP Verify', 'Done'].map((s, i) => (
                <div key={s} className="flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${(step === 'form' && i === 0) || (step === 'otp' && i === 1) || (step === 'done' && i === 2) ? 'text-white' : i < ['form','otp','done'].indexOf(step) ? 'text-white' : 'text-gray-400 bg-gray-100'}`}
                    style={{ background: (step === 'form' && i === 0) || (step === 'otp' && i === 1) || (step === 'done' && i === 2) ? '#C0392B' : i < ['form','otp','done'].indexOf(step) ? '#27AE60' : '' }}>
                    {i < ['form','otp','done'].indexOf(step) ? '✓' : i + 1}
                  </div>
                  <span className="text-xs text-gray-500">{s}</span>
                  {i < 2 && <div className="w-8 h-0.5 bg-gray-200" />}
                </div>
              ))}
            </div>

            {error && <div className="mb-4 px-4 py-3 rounded-lg text-sm text-red-700 bg-red-50 border border-red-200">⚠️ {error}</div>}
            {msg && step !== 'done' && <div className="mb-4 px-4 py-3 rounded-lg text-sm text-green-700 bg-green-50 border border-green-200">✅ {msg}</div>}

            {/* STEP 1: Registration Form */}
            {step === 'form' && (
              <form onSubmit={handleRegister} className="space-y-4">
                <h2 className="text-lg font-bold text-center mb-4" style={{ color: '#154360' }}>📝 Create Your Account</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Full Name *</label>
                    <input type="text" value={form.fullName} onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))} placeholder="Your full name" required className={inp} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Email Address *</label>
                    <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="your@email.com" required className={inp} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Phone Number *</label>
                    <input type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="98XXXXXXXX" required className={inp} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Ward Number</label>
                    <select value={form.ward} onChange={e => setForm(f => ({ ...f, ward: e.target.value }))} className={inp}>
                      <option value="">-- Select Ward --</option>
                      {WARDS.map(w => <option key={w.id} value={w.id}>{w.nameNepali} — {w.area}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Password *</label>
                    <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="Min. 8 characters" required className={inp} />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Confirm Password *</label>
                    <input type="password" value={form.confirm} onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))} placeholder="Re-enter password" required className={inp} />
                  </div>
                </div>
                <button type="submit" disabled={loading}
                  className="w-full py-3 rounded-lg text-white font-bold text-sm transition-opacity disabled:opacity-60"
                  style={{ background: '#1A5276' }}>
                  {loading ? '⏳ Registering...' : '📝 Register & Get OTP'}
                </button>
              </form>
            )}

            {/* STEP 2: OTP Verification */}
            {step === 'otp' && (
              <form onSubmit={handleVerify} className="space-y-5">
                <h2 className="text-lg font-bold text-center mb-2" style={{ color: '#154360' }}>📱 Enter OTP</h2>
                <p className="text-sm text-gray-500 text-center">We've sent a 6-digit OTP to <strong>{form.email}</strong></p>

                {devOtp && (
                  <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-300 text-center">
                    <p className="text-xs text-yellow-700 font-semibold">Development Mode — Your OTP:</p>
                    <p className="text-3xl font-bold tracking-widest mt-1" style={{ color: '#C0392B' }}>{devOtp}</p>
                    <p className="text-xs text-yellow-600 mt-1">This won't be shown in production</p>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">6-Digit OTP Code</label>
                  <input type="text" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g,'').slice(0,6))}
                    placeholder="000000" maxLength={6} required
                    className={`${inp} text-center text-2xl tracking-widest font-bold letter-spacing-wide`}
                    style={{ letterSpacing: '0.4em' }} />
                </div>
                <button type="submit" disabled={loading || otp.length !== 6}
                  className="w-full py-3 rounded-lg text-white font-bold text-sm disabled:opacity-60"
                  style={{ background: '#27AE60' }}>
                  {loading ? '⏳ Verifying...' : '✅ Verify OTP & Activate Account'}
                </button>
                <div className="text-center">
                  <button type="button" onClick={handleResend} disabled={loading}
                    className="text-sm text-blue-600 hover:underline disabled:opacity-50">
                    Didn't receive OTP? Resend
                  </button>
                </div>
              </form>
            )}

            {/* STEP 3: Done */}
            {step === 'done' && (
              <div className="text-center space-y-4">
                <div className="text-6xl">🎉</div>
                <h2 className="text-xl font-bold" style={{ color: '#27AE60' }}>Account Activated!</h2>
                <p className="text-gray-600 text-sm">{msg}</p>
                <p className="text-gray-500 text-sm">You can now log in to submit municipal service requests.</p>
                <Link href="/login" className="block w-full py-3 rounded-lg text-white font-bold text-sm text-center"
                  style={{ background: '#C0392B' }}>
                  🔐 Proceed to Login
                </Link>
              </div>
            )}

            {step === 'form' && (
              <div className="mt-5 pt-5 border-t border-gray-100 text-center">
                <p className="text-sm text-gray-600">
                  Already have an account?{' '}
                  <Link href="/login" className="font-semibold hover:underline" style={{ color: '#1A5276' }}>Login here</Link>
                </p>
              </div>
            )}
            <div className="mt-3 text-center">
              <Link href="/" className="text-xs text-gray-400 hover:text-gray-600">← Back to Home</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center py-3 text-xs text-blue-300" style={{ background: '#0d2a40' }}>
        © {new Date().getFullYear()} {MUNI_INFO.nameNepali}
      </div>
    </div>
  );
}

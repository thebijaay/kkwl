// src/app/api/admin/users/route.js
import { NextResponse } from 'next/server';
import { getAuthFromRequest } from '@/lib/auth';
import { getUsers, updateUser } from '@/lib/db';

export async function GET(request) {
  const payload = await getAuthFromRequest(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const users = getUsers()
    .filter(u => u.role !== 'admin')
    .map(({ password: _, ...u }) => u)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return NextResponse.json({ users });
}

export async function PATCH(request) {
  const payload = await getAuthFromRequest(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const { id, active } = await request.json();
  const updated = updateUser(id, { active });
  if (!updated) return NextResponse.json({ error: 'User not found' }, { status: 404 });
  const { password: _, ...safe } = updated;
  return NextResponse.json({ success: true, user: safe });
}

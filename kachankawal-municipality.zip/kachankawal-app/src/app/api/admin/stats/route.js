// src/app/api/admin/stats/route.js
import { NextResponse } from 'next/server';
import { getAuthFromRequest } from '@/lib/auth';
import { getRequests, getUsers } from '@/lib/db';

export async function GET(request) {
  const payload = await getAuthFromRequest(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const requests = getRequests();
  const users = getUsers().filter(u => u.role !== 'admin');
  return NextResponse.json({
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending').length,
    approved: requests.filter(r => r.status === 'approved').length,
    rejected: requests.filter(r => r.status === 'rejected').length,
    processing: requests.filter(r => r.status === 'processing').length,
    totalUsers: users.length,
    activeUsers: users.filter(u => u.active).length,
  });
}

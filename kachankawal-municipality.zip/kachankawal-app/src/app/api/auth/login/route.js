// src/app/api/auth/login/route.js
import { NextResponse } from 'next/server';
import { findUserByEmail, findUserByUsername, ensureAdminExists } from '@/lib/db';
import { comparePassword, signToken, COOKIE_OPTIONS } from '@/lib/auth';

export async function POST(request) {
  try {
    await ensureAdminExists();
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password required' }, { status: 400 });
    }

    // Find by username or email
    let user = findUserByUsername(username) || findUserByEmail(username);
    if (!user) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    if (!user.active) {
      return NextResponse.json({ error: 'Account not activated. Please verify your OTP.' }, { status: 403 });
    }

    const valid = await comparePassword(password, user.password);
    if (!valid) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    const token = await signToken({ id: user.id, username: user.username, role: user.role, email: user.email });

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, username: user.username, fullName: user.fullName, email: user.email, role: user.role },
    });
    response.cookies.set('kmc_token', token, COOKIE_OPTIONS);
    return response;
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

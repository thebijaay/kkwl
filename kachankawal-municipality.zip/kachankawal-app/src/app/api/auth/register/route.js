// src/app/api/auth/register/route.js
import { NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { findUserByEmail, createUser, saveOTP } from '@/lib/db';
import { hashPassword, generateOTP } from '@/lib/auth';

export async function POST(request) {
  try {
    const { fullName, email, phone, password, ward } = await request.json();

    if (!fullName || !email || !phone || !password) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 });
    }

    const existing = findUserByEmail(email);
    if (existing) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
    }

    const hashed = await hashPassword(password);
    const otp = generateOTP();

    // Create inactive user
    createUser({
      id: uuidv4(),
      username: email.split('@')[0] + '_' + Date.now().toString().slice(-4),
      fullName,
      email,
      phone,
      password: hashed,
      ward: ward || null,
      role: 'user',
      active: false, // activated after OTP verification
    });

    // Save OTP
    saveOTP(email, otp);

    // In production, send OTP via email/SMS
    // For development: return OTP in response
    console.log(`[OTP] ${email}: ${otp}`);

    return NextResponse.json({
      success: true,
      message: 'Registration successful. Please verify your OTP to activate your account.',
      // In dev mode, expose OTP. Remove in production.
      ...(process.env.NODE_ENV !== 'production' && { otp, devNote: 'OTP shown for development only' }),
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

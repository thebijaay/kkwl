// src/app/api/auth/verify-otp/route.js
import { NextResponse } from 'next/server';
import { findUserByEmail, updateUser, verifyOTP, deleteOTP, saveOTP } from '@/lib/db';
import { generateOTP } from '@/lib/auth';

export async function POST(request) {
  try {
    const { email, otp, action } = await request.json();

    if (!email) return NextResponse.json({ error: 'Email required' }, { status: 400 });

    // Resend OTP
    if (action === 'resend') {
      const user = findUserByEmail(email);
      if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });
      const newOtp = generateOTP();
      saveOTP(email, newOtp);
      console.log(`[OTP Resend] ${email}: ${newOtp}`);
      return NextResponse.json({
        success: true,
        message: 'OTP resent successfully.',
        ...(process.env.NODE_ENV !== 'production' && { otp: newOtp }),
      });
    }

    // Verify OTP
    if (!otp) return NextResponse.json({ error: 'OTP required' }, { status: 400 });

    const valid = verifyOTP(email, otp);
    if (!valid) return NextResponse.json({ error: 'Invalid or expired OTP' }, { status: 400 });

    const user = findUserByEmail(email);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    updateUser(user.id, { active: true });
    deleteOTP(email);

    return NextResponse.json({ success: true, message: 'Account verified successfully! You can now log in.' });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

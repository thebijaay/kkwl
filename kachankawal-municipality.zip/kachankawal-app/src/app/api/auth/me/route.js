// src/app/api/auth/me/route.js
import { NextResponse } from 'next/server';
import { getAuthFromRequest } from '@/lib/auth';
import { findUserById } from '@/lib/db';

export async function GET(request) {
  const payload = await getAuthFromRequest(request);
  if (!payload) return NextResponse.json({ user: null }, { status: 401 });
  const user = findUserById(payload.id);
  if (!user) return NextResponse.json({ user: null }, { status: 401 });
  const { password: _, ...safeUser } = user;
  return NextResponse.json({ user: safeUser });
}

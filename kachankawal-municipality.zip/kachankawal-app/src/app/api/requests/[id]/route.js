// src/app/api/requests/[id]/route.js
import { NextResponse } from 'next/server';
import { getAuthFromRequest } from '@/lib/auth';
import { getRequestById, updateRequest } from '@/lib/db';

export async function PATCH(request, { params }) {
  const payload = await getAuthFromRequest(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const { status, adminNote } = await request.json();
    if (!['pending', 'approved', 'rejected', 'processing'].includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
    }
    const req = getRequestById(params.id);
    if (!req) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    const updated = updateRequest(params.id, { status, adminNote: adminNote || '' });
    return NextResponse.json({ success: true, request: updated });
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function GET(request, { params }) {
  const payload = await getAuthFromRequest(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const req = getRequestById(params.id);
  if (!req) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (payload.role !== 'admin' && req.userId !== payload.id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  return NextResponse.json({ request: req });
}

// src/app/api/requests/route.js
import { NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { getAuthFromRequest } from '@/lib/auth';
import { getRequests, getRequestsByUser, createRequest } from '@/lib/db';

export async function GET(request) {
  const payload = await getAuthFromRequest(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  if (payload.role === 'admin') {
    const all = getRequests().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return NextResponse.json({ requests: all });
  }
  const mine = getRequestsByUser(payload.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return NextResponse.json({ requests: mine });
}

export async function POST(request) {
  const payload = await getAuthFromRequest(request);
  if (!payload || payload.role === 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { serviceType, ward, description, documents } = body;

    if (!serviceType || !ward || !description) {
      return NextResponse.json({ error: 'serviceType, ward, and description are required' }, { status: 400 });
    }

    const req = createRequest({
      id: uuidv4(),
      userId: payload.id,
      userName: payload.username,
      userEmail: payload.email,
      serviceType,
      ward,
      description,
      documents: documents || '',
    });

    return NextResponse.json({ success: true, request: req }, { status: 201 });
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

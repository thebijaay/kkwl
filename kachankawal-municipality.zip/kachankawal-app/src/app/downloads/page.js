import Link from 'next/link';
import { DOWNLOADS } from '@/lib/data';

export const metadata = { title: 'डाउनलोड / फारम — Kachankawal Rural Municipality' };

const CATS = [
  { key: 'forms', label: '📋 नमुना फारमहरु', id: 'forms' },
  { key: 'budget', label: '💰 बजेट तथा कार्यक्रम', id: 'budget' },
  { key: 'reports', label: '📊 प्रतिवेदनहरू', id: 'reports' },
  { key: 'laws', label: '⚖️ ऐन तथा नियमावली', id: 'laws' },
];

export default function DownloadsPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4">
        <Link href="/">गृहपृष्ठ</Link> › <span className="text-red-700 font-semibold">डाउनलोड / फारम</span>
      </div>
      <h1 className="text-3xl font-bold mb-6" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>
        डाउनलोड / नमुना फारमहरु
      </h1>

      {/* Quick jump */}
      <div className="flex flex-wrap gap-2 mb-8">
        {CATS.map(c => (
          <a key={c.key} href={`#${c.id}`}
            className="text-sm font-semibold px-4 py-2 rounded-lg border transition-colors hover:text-white"
            style={{ color: '#1A5276', borderColor: '#1A5276' }}
            onMouseEnter={e => { e.currentTarget.style.background = '#1A5276'; e.currentTarget.style.color = '#fff'; }}
            onMouseLeave={e => { e.currentTarget.style.background = ''; e.currentTarget.style.color = '#1A5276'; }}>
            {c.label}
          </a>
        ))}
      </div>

      {CATS.map(cat => {
        const items = DOWNLOADS.filter(d => d.category === cat.key);
        if (!items.length) return null;
        return (
          <section key={cat.key} id={cat.id} className="mb-8 scroll-mt-20">
            <h2 className="text-lg font-bold mb-3 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
              {cat.label}
            </h2>
            <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
              {items.map((d, i) => (
                <div key={d.id} className={`flex items-center gap-4 px-4 py-3 hover:bg-gray-50 transition-colors ${i < items.length - 1 ? 'border-b border-gray-100' : ''}`}>
                  <span className="text-2xl flex-shrink-0">
                    {cat.key === 'forms' ? '📋' : cat.key === 'budget' ? '💰' : cat.key === 'reports' ? '📊' : '⚖️'}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-800 text-sm leading-snug">{d.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{d.nepali}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{d.format} &nbsp;·&nbsp; {d.size} &nbsp;·&nbsp; {d.year}</p>
                  </div>
                  <button
                    className="text-xs font-semibold text-white px-4 py-1.5 rounded flex-shrink-0 transition-opacity hover:opacity-80"
                    style={{ background: '#C0392B' }}>
                    ⬇ Download
                  </button>
                </div>
              ))}
            </div>
          </section>
        );
      })}

      {/* Monthly/Annual Reports extra section */}
      <section id="monthly" className="mb-8 scroll-mt-20">
        <h2 className="text-lg font-bold mb-3 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          📅 मासिक प्रगति प्रतिवेदन
        </h2>
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {['असोज २०८२', 'भदौ २०८२', 'साउन २०८२', 'असार २०८२', 'जेठ २०८२'].map((m, i) => (
            <div key={m} className={`flex items-center gap-3 px-4 py-3 hover:bg-gray-50 ${i < 4 ? 'border-b border-gray-100' : ''}`}>
              <span className="text-lg">📄</span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-gray-800">मासिक प्रगति प्रतिवेदन — {m}</p>
              </div>
              <button className="text-xs font-semibold text-white px-3 py-1.5 rounded" style={{ background: '#1A5276' }}>⬇ Download</button>
            </div>
          ))}
        </div>
      </section>

      <section id="audit" className="scroll-mt-20">
        <h2 className="text-lg font-bold mb-3 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          🔍 लेखा परीक्षण / अनुगमन प्रतिवेदन
        </h2>
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {[
            'लेखापरीक्षण प्रतिवेदन आ.व. २०८०/८१',
            'अनुगमन प्रतिवेदन द्वितीय चौमासिक — आ.व. २०८१/८२',
            'सार्वजनिक सुनुवाई प्रतिवेदन — २०८२',
            'सामाजिक परिक्षण प्रतिवेदन — २०८१/८२',
          ].map((r, i) => (
            <div key={r} className={`flex items-center gap-3 px-4 py-3 hover:bg-gray-50 ${i < 3 ? 'border-b border-gray-100' : ''}`}>
              <span className="text-lg">📋</span>
              <p className="flex-1 text-sm font-semibold text-gray-800">{r}</p>
              <button className="text-xs font-semibold text-white px-3 py-1.5 rounded" style={{ background: '#1A5276' }}>⬇ Download</button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

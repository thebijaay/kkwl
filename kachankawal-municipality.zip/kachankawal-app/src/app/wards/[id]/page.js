import Link from 'next/link';
import { notFound } from 'next/navigation';
import { WARDS } from '@/lib/data';

export async function generateStaticParams() {
  return WARDS.map(w => ({ id: String(w.id) }));
}

export async function generateMetadata({ params }) {
  const w = WARDS.find(w => w.id === Number(params.id));
  if (!w) return {};
  return { title: `${w.nameNepali} — Kachankawal Rural Municipality` };
}

export default function WardPage({ params }) {
  const ward = WARDS.find(w => w.id === Number(params.id));
  if (!ward) notFound();

  const prev = WARDS.find(w => w.id === ward.id - 1);
  const next = WARDS.find(w => w.id === ward.id + 1);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4">
        <Link href="/">गृहपृष्ठ</Link> › <Link href="/wards">वडा कार्यालय</Link> › <span className="text-red-700 font-semibold">{ward.nameNepali}</span>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-6 text-white" style={{ background: 'linear-gradient(135deg,#154360,#1A5276)' }}>
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-full flex items-center justify-center font-bold text-3xl border-2 flex-shrink-0"
              style={{ background: 'rgba(255,255,255,0.15)', borderColor: '#D4AC0D' }}>
              {ward.id}
            </div>
            <div>
              <h1 className="text-2xl font-bold" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{ward.nameNepali}</h1>
              <p className="text-blue-200">{ward.nameEnglish}</p>
              <p className="text-blue-300 text-sm mt-0.5">कचनकवल गाउँपालिका — {ward.area}</p>
            </div>
          </div>
        </div>

        {/* Details */}
        <div className="p-6">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            {[
              { label: 'वडा नम्बर', value: ward.id },
              { label: 'वडाध्यक्ष', value: ward.chairperson },
              { label: 'फोन', value: ward.phone },
              { label: 'इमेल', value: ward.email },
              { label: 'ठेगाना', value: ward.area },
              { label: 'गाउँ/टोल', value: ward.villages },
              { label: 'जनसंख्या', value: ward.population },
              { label: 'घरधुरी', value: ward.households },
              { label: 'जिल्ला', value: 'झापा' },
            ].map(d => (
              <div key={d.label} className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                <div className="text-xs text-gray-500 mb-0.5">{d.label}</div>
                <div className="font-semibold text-sm text-gray-800 break-all">{d.value}</div>
              </div>
            ))}
          </div>

          {/* Services */}
          <h2 className="font-bold text-blue-900 mb-3">वडा कार्यालयमा उपलब्ध सेवाहरू</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-6">
            {[
              'जन्म / मृत्यु / विवाह दर्ता', 'नागरिकता सिफारिस', 'बसोबास प्रमाणपत्र',
              'सामाजिक सुरक्षा वितरण', 'स्थानीय कर संकलन', 'व्यवसाय दर्ता (स्थानीय)',
              'कृषि अनुदान आवेदन', 'छात्रवृत्ति सिफारिस', 'गुनासो दर्ता',
            ].map(s => (
              <div key={s} className="flex items-start gap-2 text-xs text-gray-600">
                <span className="text-green-500 mt-0.5 flex-shrink-0">✓</span> {s}
              </div>
            ))}
          </div>

          {/* Contact */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h3 className="font-bold text-blue-900 mb-2">📞 {ward.nameNepali} सम्पर्क</h3>
            <div className="grid sm:grid-cols-2 gap-2 text-sm text-gray-600">
              <p>📞 {ward.phone}</p>
              <p>📧 {ward.email}</p>
              <p>📍 {ward.area}, झापा</p>
              <p>🕐 आइतबार–शुक्रबार, बिहान १०:०० – साँझ ५:००</p>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            {prev ? (
              <Link href={`/wards/${prev.id}`} className="text-sm font-semibold text-white px-4 py-2 rounded transition-opacity hover:opacity-80"
                style={{ background: '#1A5276' }}>← {prev.nameNepali}</Link>
            ) : <span />}
            <Link href="/wards" className="text-sm font-semibold px-4 py-2 rounded border transition-colors hover:text-white hover:bg-blue-800"
              style={{ color: '#1A5276', borderColor: '#1A5276' }}>सबै वडाहरू</Link>
            {next ? (
              <Link href={`/wards/${next.id}`} className="text-sm font-semibold text-white px-4 py-2 rounded transition-opacity hover:opacity-80"
                style={{ background: '#1A5276' }}>{next.nameNepali} →</Link>
            ) : <span />}
          </div>
        </div>
      </div>
    </div>
  );
}

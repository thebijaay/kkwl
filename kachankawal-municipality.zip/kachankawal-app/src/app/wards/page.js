import Link from 'next/link';
import { WARDS } from '@/lib/data';
export const metadata = { title: 'वडा कार्यालयहरू — Kachankawal Rural Municipality' };
export default function WardsPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4"><Link href="/">गृहपृष्ठ</Link> › <span className="text-red-700 font-semibold">वडा कार्यालयहरू</span></div>
      <h1 className="text-3xl font-bold mb-2" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>वडा कार्यालयहरू</h1>
      <p className="text-gray-500 text-sm mb-6">कचनकवल गाउँपालिकाका ७ वडा कार्यालयहरूको विवरण</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {WARDS.map(w => (
          <Link key={w.id} href={`/wards/${w.id}`} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md hover:border-red-400 transition-all group block">
            <div className="flex items-center gap-3 mb-3">
              <span className="w-12 h-12 rounded-full flex items-center justify-center font-bold text-white text-lg flex-shrink-0" style={{ background: '#1A5276' }}>{w.id}</span>
              <div>
                <div className="font-bold text-gray-900 group-hover:text-red-700 transition-colors" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{w.nameNepali}</div>
                <div className="text-xs text-gray-500">{w.nameEnglish}</div>
              </div>
            </div>
            <div className="space-y-1 text-xs text-gray-500">
              <p>👤 वडाध्यक्ष: <strong className="text-gray-700">{w.chairperson}</strong></p>
              <p>📍 {w.area}</p>
              <p>🏘️ {w.villages}</p>
              <p>👥 जनसंख्या: {w.population} &nbsp;|&nbsp; घरधुरी: {w.households}</p>
              <p>📞 {w.phone}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

import Link from 'next/link';
import { NOTICES, TENDERS, NEWS } from '@/lib/data';

export const metadata = { title: 'सूचना तथा जानकारी — Kachankawal Rural Municipality' };

function Badge({ children, color }) {
  return (
    <span className="text-white text-xs px-2 py-0.5 rounded font-semibold flex-shrink-0"
      style={{ background: color }}>{children}</span>
  );
}

export default function NoticesPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4">
        <Link href="/">गृहपृष्ठ</Link> › <span className="text-red-700 font-semibold">सूचना तथा जानकारी</span>
      </div>
      <h1 className="text-3xl font-bold mb-6" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>
        सूचना तथा जानकारी
      </h1>

      {/* NOTICES */}
      <section id="notices" className="mb-10 scroll-mt-20">
        <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          📢 सूचना तथा परिपत्र
        </h2>
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {NOTICES.map((n, i) => (
            <div key={n.id} className={`flex gap-3 items-start px-4 py-4 hover:bg-gray-50 cursor-pointer transition-colors ${i < NOTICES.length - 1 ? 'border-b border-gray-100' : ''}`}>
              <Badge color={n.urgent ? '#C0392B' : '#1A5276'}>{n.urgent ? '🔴 जरुरी' : 'सूचना'}</Badge>
              <div className="flex-1">
                <p className="font-semibold text-gray-800 text-sm leading-snug">{n.title}</p>
                <p className="text-xs text-gray-400 mt-0.5">📅 {n.date} ({n.dateEn})</p>
              </div>
              <button className="text-xs font-semibold px-3 py-1 rounded border flex-shrink-0 hover:bg-gray-50"
                style={{ color: '#1A5276', borderColor: '#1A5276' }}>⬇ Download</button>
            </div>
          ))}
        </div>
      </section>

      {/* TENDERS */}
      <section id="tenders" className="mb-10 scroll-mt-20">
        <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          🏗️ सार्वजनिक खरिद / बोलपत्र सूचना
        </h2>
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {TENDERS.map((t, i) => (
            <div key={t.id} className={`flex gap-3 items-start px-4 py-4 hover:bg-gray-50 cursor-pointer transition-colors ${i < TENDERS.length - 1 ? 'border-b border-gray-100' : ''}`}>
              <Badge color="#1A5276">बोलपत्र</Badge>
              <div className="flex-1">
                <p className="font-semibold text-gray-800 text-sm leading-snug mb-1">{t.title}</p>
                <div className="flex flex-wrap gap-x-4 gap-y-0.5">
                  <p className="text-xs text-gray-400">📅 प्रकाशित: {t.dateEn}</p>
                  <p className="text-xs text-red-600 font-semibold">⏰ म्याद: {t.deadline}</p>
                  <p className="text-xs text-green-700 font-semibold">💰 {t.amount}</p>
                </div>
              </div>
              <button className="text-xs font-semibold px-3 py-1 rounded flex-shrink-0 text-white"
                style={{ background: '#1A5276' }}>⬇ Download</button>
            </div>
          ))}
        </div>
      </section>

      {/* NEWS */}
      <section id="news" className="mb-10 scroll-mt-20">
        <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          📰 समाचार तथा घटनाहरू
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {NEWS.map(n => (
            <div key={n.id} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
              <Badge color="#27AE60">समाचार</Badge>
              <h3 className="font-bold text-gray-800 mt-2 mb-1 text-sm leading-snug">{n.title}</h3>
              <p className="text-xs text-gray-400 mb-2">📅 {n.date}</p>
              <p className="text-xs text-gray-600 leading-relaxed">{n.summary}</p>
            </div>
          ))}
        </div>
      </section>

      {/* DECISIONS */}
      <section id="decisions" className="mb-10 scroll-mt-20">
        <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          ⚖️ निर्णयहरू
        </h2>
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {[
            { title: 'गाउँसभाको नियमित बैठकका निर्णयहरू — २०८२ असोज', date: '२०८२-०६-२०', type: 'गाउँसभा' },
            { title: 'कार्यपालिका बोर्डको बैठकका निर्णयहरू — २०८२ भदौ', date: '२०८२-०५-१५', type: 'कार्यपालिका' },
            { title: 'गाउँपालिकाको नीति तथा कार्यक्रम — आ.व. २०८२/८३', date: '२०८२-०४-०१', type: 'गाउँपालिका' },
            { title: 'कार्यपालिका बोर्डको विशेष बैठकका निर्णयहरू — २०८२ साउन', date: '२०८२-०४-०५', type: 'कार्यपालिका' },
          ].map((d, i) => (
            <div key={d.title} className={`flex gap-3 items-center px-4 py-3 hover:bg-gray-50 ${i < 3 ? 'border-b border-gray-100' : ''}`}>
              <Badge color={d.type === 'गाउँसभा' ? '#7C3AED' : d.type === 'कार्यपालिका' ? '#1A5276' : '#C0392B'}>{d.type}</Badge>
              <div className="flex-1">
                <p className="text-sm font-semibold text-gray-800">{d.title}</p>
                <p className="text-xs text-gray-400">📅 {d.date}</p>
              </div>
              <button className="text-xs text-white font-semibold px-3 py-1 rounded" style={{ background: '#154360' }}>⬇</button>
            </div>
          ))}
        </div>
      </section>

      {/* GAZETTE */}
      <section id="gazette" className="scroll-mt-20">
        <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          📜 स्थानीय राजपत्र
        </h2>
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          {[
            { title: 'कचनकवल गाउँपालिका राजपत्र — अंक ४, भाग २०८२', date: 'Ashadh 2082' },
            { title: 'कचनकवल गाउँपालिका राजपत्र — अंक ३, भाग २०८१', date: 'Ashadh 2081' },
          ].map((g, i) => (
            <div key={g.title} className={`flex items-center gap-3 px-4 py-3 hover:bg-gray-50 cursor-pointer ${i < 1 ? 'border-b border-gray-100' : ''}`}>
              <span className="text-xl">📋</span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-gray-800">{g.title}</p>
                <p className="text-xs text-gray-400">📅 {g.date}</p>
              </div>
              <button className="text-xs text-white font-semibold px-3 py-1 rounded" style={{ background: '#1A5276' }}>⬇ Download</button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

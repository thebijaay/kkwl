'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { SERVICES, WARDS, MUNI_INFO } from '@/lib/data';

const STATUS_STYLES = {
  pending: 'status-pending',
  approved: 'status-approved',
  rejected: 'status-rejected',
  processing: 'status-processing',
};
const STATUS_LABELS = { pending: '⏳ Pending', approved: '✅ Approved', rejected: '❌ Rejected', processing: '🔄 Processing' };

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [requests, setRequests] = useState([]);
  const [tab, setTab] = useState('list'); // 'list' | 'new'
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ serviceType: '', ward: '', description: '', documents: '' });
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/auth/me').then(r => r.json()).then(d => {
      if (!d.user) { router.push('/login?redirect=/dashboard'); return; }
      setUser(d.user);
    });
    loadRequests();
  }, []);

  async function loadRequests() {
    const r = await fetch('/api/requests');
    if (r.ok) { const d = await r.json(); setRequests(d.requests || []); }
    setLoading(false);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setMsg(''); setSubmitting(true);
    try {
      const r = await fetch('/api/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const d = await r.json();
      if (!r.ok) { setError(d.error || 'Submission failed'); return; }
      setMsg('✅ Request submitted successfully! You can track it below.');
      setForm({ serviceType: '', ward: '', description: '', documents: '' });
      setTab('list');
      loadRequests();
    } catch { setError('Network error.'); }
    finally { setSubmitting(false); }
  }

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  }

  const inp = "w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-500";

  return (
    <div className="min-h-screen" style={{ background: '#F4F6F8' }}>
      {/* Top nav */}
      <div className="text-white shadow-lg" style={{ background: '#154360' }}>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🏡</span>
            <div>
              <div className="font-bold text-sm" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{MUNI_INFO.nameNepali}</div>
              <div className="text-blue-300 text-xs">Citizen Dashboard</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {user && <span className="text-sm text-blue-200">👤 {user.fullName || user.username}</span>}
            <Link href="/" className="text-blue-300 text-xs hover:text-white">← Home</Link>
            <button onClick={logout} className="text-white text-xs px-3 py-1.5 rounded" style={{ background: '#C0392B' }}>Logout</button>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>
            Citizen Service Portal
          </h1>
          <button onClick={() => { setTab('new'); setMsg(''); setError(''); }}
            className="text-white font-bold px-5 py-2 rounded-lg text-sm" style={{ background: '#C0392B' }}>
            + New Request
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Total', val: requests.length, color: '#1A5276' },
            { label: 'Pending', val: requests.filter(r => r.status === 'pending').length, color: '#D97706' },
            { label: 'Approved', val: requests.filter(r => r.status === 'approved').length, color: '#059669' },
            { label: 'Rejected', val: requests.filter(r => r.status === 'rejected').length, color: '#DC2626' },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-lg p-4 text-center shadow-sm border border-gray-200">
              <div className="text-2xl font-bold" style={{ color: s.color }}>{s.val}</div>
              <div className="text-xs text-gray-500 mt-0.5">{s.label} Requests</div>
            </div>
          ))}
        </div>

        {msg && <div className="mb-4 px-4 py-3 rounded-lg text-sm text-green-700 bg-green-50 border border-green-200">{msg}</div>}

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="flex border-b border-gray-200">
            {[['list','📋 My Requests'], ['new','➕ New Request']].map(([key, lbl]) => (
              <button key={key} onClick={() => setTab(key)}
                className={`px-6 py-3 text-sm font-semibold transition-colors ${tab === key ? 'text-white' : 'text-gray-600 hover:bg-gray-50'}`}
                style={tab === key ? { background: '#1A5276' } : {}}>
                {lbl}
              </button>
            ))}
          </div>

          {/* LIST TAB */}
          {tab === 'list' && (
            <div>
              {loading ? (
                <div className="py-12 text-center text-gray-400">Loading requests...</div>
              ) : requests.length === 0 ? (
                <div className="py-12 text-center">
                  <div className="text-5xl mb-3">📋</div>
                  <p className="text-gray-500 font-semibold">No requests yet</p>
                  <p className="text-gray-400 text-sm mt-1">Submit your first service request</p>
                  <button onClick={() => setTab('new')} className="mt-4 text-white font-bold px-5 py-2 rounded-lg text-sm"
                    style={{ background: '#C0392B' }}>+ New Request</button>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {requests.map(req => (
                    <div key={req.id} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between gap-4 flex-wrap">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="font-bold text-gray-800 text-sm">{req.serviceType}</span>
                            <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${STATUS_STYLES[req.status]}`}>
                              {STATUS_LABELS[req.status]}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 mb-1">{req.description}</p>
                          <div className="text-xs text-gray-400 flex gap-4 flex-wrap">
                            <span>📍 Ward {req.ward}</span>
                            <span>📅 {new Date(req.createdAt).toLocaleDateString()}</span>
                            <span>🆔 {req.id.slice(0, 8)}...</span>
                          </div>
                          {req.adminNote && (
                            <div className="mt-2 px-3 py-2 rounded text-xs text-blue-700 bg-blue-50 border border-blue-200">
                              <strong>Admin Note:</strong> {req.adminNote}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* NEW REQUEST TAB */}
          {tab === 'new' && (
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              <h2 className="text-lg font-bold" style={{ color: '#154360' }}>Submit New Service Request</h2>
              {error && <div className="px-4 py-3 rounded-lg text-sm text-red-700 bg-red-50 border border-red-200">⚠️ {error}</div>}
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Service Type *</label>
                  <select value={form.serviceType} onChange={e => setForm(f => ({ ...f, serviceType: e.target.value }))} required className={inp}>
                    <option value="">-- Select Service --</option>
                    {SERVICES.map(s => <option key={s.id} value={s.title}>{s.icon} {s.title} — {s.titleNp}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Ward Number *</label>
                  <select value={form.ward} onChange={e => setForm(f => ({ ...f, ward: e.target.value }))} required className={inp}>
                    <option value="">-- Select Ward --</option>
                    {WARDS.map(w => <option key={w.id} value={w.id}>{w.nameNepali} — {w.area}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description / Details *</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  rows={4} required placeholder="Describe your request in detail..."
                  className={`${inp} resize-none`} />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Documents / Attachments (optional)</label>
                <input type="text" value={form.documents} onChange={e => setForm(f => ({ ...f, documents: e.target.value }))}
                  placeholder="List any documents you will bring (e.g., citizenship card, household registration)"
                  className={inp} />
              </div>
              <div className="flex gap-3">
                <button type="submit" disabled={submitting}
                  className="text-white font-bold px-8 py-2.5 rounded-lg text-sm disabled:opacity-60"
                  style={{ background: '#C0392B' }}>
                  {submitting ? '⏳ Submitting...' : '📤 Submit Request'}
                </button>
                <button type="button" onClick={() => setTab('list')}
                  className="font-bold px-5 py-2.5 rounded-lg text-sm border" style={{ color: '#1A5276', borderColor: '#1A5276' }}>
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

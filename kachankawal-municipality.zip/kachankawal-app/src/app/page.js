import Link from 'next/link';
import HeroSlider from '@/components/HeroSlider';
import { MUNI_INFO, NOTICES, TENDERS, NEWS, SERVICES, WARDS } from '@/lib/data';

function Card({ children, className = '' }) {
  return <div className={`bg-white border border-gray-200 rounded-md shadow-sm overflow-hidden ${className}`}>{children}</div>;
}
function CardHeader({ children, link, linkLabel = 'सबै हेर्नुहोस् →' }) {
  return (
    <div className="flex justify-between items-center px-4 py-2.5 font-bold text-sm text-white" style={{ background: '#1A5276' }}>
      <span>{children}</span>
      {link && <Link href={link} className="text-yellow-300 font-normal text-xs hover:text-white">{linkLabel}</Link>}
    </div>
  );
}
function SecTitle({ children }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <h3 className="text-xl font-bold whitespace-nowrap" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>{children}</h3>
      <div className="flex-1 h-0.5" style={{ background: 'linear-gradient(to right,#C0392B,transparent)' }} />
    </div>
  );
}

export default function Home() {
  return (
    <div>
      <HeroSlider />
      <div className="max-w-6xl mx-auto px-4 py-6">

        {/* QUICK SERVICES */}
        <section className="mb-8">
          <SecTitle>⚡ त्वरित सेवाहरू</SecTitle>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {SERVICES.map(s => (
              <Link key={s.id} href="/services"
                className="bg-white border border-gray-200 rounded-lg p-3 text-center hover:border-red-500 hover:shadow-md transition-all group block">
                <span className="text-2xl block mb-1">{s.icon}</span>
                <span className="text-xs font-semibold leading-tight block" style={{ color: '#154360' }}>{s.title}</span>
                <span className="text-xs text-gray-400 block mt-0.5" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{s.titleNp}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* ONLINE REQUEST BANNER */}
        <div className="mb-8 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4"
          style={{ background: 'linear-gradient(135deg,#154360,#1A5276)', color: '#fff' }}>
          <div>
            <h3 className="text-lg font-bold">🖥️ Online Service Request Portal</h3>
            <p className="text-sm text-blue-200 mt-1">Login or register to submit and track your municipal service requests online</p>
          </div>
          <div className="flex gap-3 flex-shrink-0">
            <Link href="/login" className="text-white font-bold px-5 py-2 rounded text-sm" style={{ background: '#C0392B' }}>🔐 Login</Link>
            <Link href="/register" className="font-bold px-5 py-2 rounded text-sm border-2 border-white text-white hover:bg-white/10 transition-colors">📝 Register</Link>
          </div>
        </div>

        {/* MAIN GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-5">

            {/* NOTICES */}
            <Card>
              <CardHeader link="/notices">📢 सूचना तथा समाचार</CardHeader>
              {NOTICES.slice(0, 6).map(n => (
                <div key={n.id} className="flex gap-3 items-start px-4 py-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors">
                  <span className="text-white text-xs px-2 py-0.5 rounded mt-0.5 flex-shrink-0"
                    style={{ background: n.urgent ? '#C0392B' : '#1A5276' }}>
                    {n.urgent ? '🔴 जरुरी' : 'सूचना'}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-gray-800 leading-snug">{n.title}</p>
                    <p className="text-xs text-gray-400 mt-0.5">📅 {n.date} | {n.dateEn}</p>
                  </div>
                </div>
              ))}
              <div className="px-4 py-2 text-right">
                <Link href="/notices" className="text-xs font-semibold hover:underline" style={{ color: '#1A5276' }}>सबै सूचनाहरू →</Link>
              </div>
            </Card>

            {/* TENDERS */}
            <Card>
              <CardHeader link="/notices#tenders">🏗️ बोलपत्र / सार्वजनिक खरिद सूचना</CardHeader>
              {TENDERS.slice(0, 4).map(t => (
                <div key={t.id} className="flex gap-3 items-start px-4 py-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors">
                  <span className="text-white text-xs px-2 py-0.5 rounded mt-0.5 flex-shrink-0" style={{ background: '#1A5276' }}>बोलपत्र</span>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-800 leading-snug">{t.title}</p>
                    <div className="flex flex-wrap gap-x-4 mt-0.5">
                      <p className="text-xs text-gray-400">📅 {t.dateEn}</p>
                      <p className="text-xs text-red-600 font-semibold">⏰ Deadline: {t.deadline}</p>
                      <p className="text-xs text-green-700">💰 {t.amount}</p>
                    </div>
                  </div>
                </div>
              ))}
              <div className="px-4 py-2 text-right">
                <Link href="/notices#tenders" className="text-xs font-semibold hover:underline" style={{ color: '#1A5276' }}>सबै बोलपत्रहरू →</Link>
              </div>
            </Card>

            {/* WARDS */}
            <Card>
              <CardHeader link="/wards">🗺️ वडा कार्यालयहरू</CardHeader>
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {WARDS.map(w => (
                  <Link key={w.id} href={`/wards/${w.id}`}
                    className="flex items-center gap-3 border border-gray-200 rounded-lg p-3 hover:border-red-400 hover:shadow-sm transition-all group">
                    <span className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-sm flex-shrink-0"
                      style={{ background: '#1A5276' }}>{w.id}</span>
                    <div>
                      <div className="font-bold text-sm text-gray-800 group-hover:text-red-700 transition-colors"
                        style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{w.nameNepali}</div>
                      <div className="text-xs text-gray-500">👤 {w.chairperson}</div>
                      <div className="text-xs text-gray-400">📍 {w.area}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </Card>
          </div>

          {/* SIDEBAR */}
          <div className="space-y-4">
            {/* STATS */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { n: '7', l: 'वडाहरू' }, { n: '38K+', l: 'जनसंख्या' },
                { n: 'झापा', l: 'जिल्ला' }, { n: 'कोशी', l: 'प्रदेश' },
              ].map(s => (
                <div key={s.l} className="bg-white border border-gray-200 rounded-md p-3 text-center shadow-sm">
                  <div className="text-2xl font-bold" style={{ color: '#C0392B', fontFamily: 'Crimson Pro, serif' }}>{s.n}</div>
                  <div className="text-xs text-gray-500 mt-0.5" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{s.l}</div>
                </div>
              ))}
            </div>

            {/* CHAIRMAN */}
            <Card>
              <div className="p-4 text-center">
                <div className="w-20 h-20 rounded-full mx-auto mb-3 flex items-center justify-center text-4xl border-2"
                  style={{ background: 'linear-gradient(135deg,#1A5276,#154360)', borderColor: '#D4AC0D' }}>👤</div>
                <h4 className="font-bold text-blue-900 text-sm" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>
                  {MUNI_INFO.chairman.nameNepali}
                </h4>
                <p className="text-xs text-gray-500">{MUNI_INFO.chairman.title}</p>
                <p className="text-xs text-gray-400 mt-0.5">{MUNI_INFO.nameNepali}</p>
                <blockquote className="text-xs text-gray-600 mt-3 italic border-l-2 pl-3 text-left leading-relaxed" style={{ borderColor: '#C0392B' }}>
                  "{MUNI_INFO.chairman.message}"
                </blockquote>
                <Link href="/contact" className="mt-3 block text-white text-sm font-semibold py-2 rounded" style={{ background: '#C0392B' }}>
                  📣 सम्पर्क गर्नुहोस्
                </Link>
              </div>
            </Card>

            {/* NEWS */}
            <Card>
              <CardHeader link="/notices#news">📰 ताजा समाचार</CardHeader>
              {NEWS.slice(0, 3).map(n => (
                <div key={n.id} className="px-4 py-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer">
                  <span className="text-white text-xs px-2 py-0.5 rounded" style={{ background: '#27AE60' }}>समाचार</span>
                  <p className="text-sm font-semibold text-gray-800 mt-1 leading-snug">{n.title}</p>
                  <p className="text-xs text-gray-400 mt-0.5">📅 {n.date}</p>
                </div>
              ))}
            </Card>

            {/* IMPORTANT LINKS */}
            <Card>
              <CardHeader>🔗 महत्वपूर्ण लिंकहरू</CardHeader>
              <div className="divide-y divide-gray-100">
                {[
                  { label: '🇳🇵 Nepal Government Portal', href: 'https://nepal.gov.np' },
                  { label: '📋 Citizen Charter', href: '/services#charter' },
                  { label: '📁 Sample Forms / नमुना फारम', href: '/downloads' },
                  { label: '📊 Budget & Programme', href: '/downloads#budget' },
                  { label: '⚖️ Local Laws & Bylaws', href: '/downloads#laws' },
                  { label: '🔐 Online Service Request', href: '/dashboard' },
                ].map(l => (
                  <a key={l.label} href={l.href}
                    className="flex items-center px-4 py-2.5 text-sm text-blue-800 hover:bg-gray-50 hover:text-red-700 transition-colors">
                    {l.label}
                  </a>
                ))}
              </div>
            </Card>

            {/* CONTACT */}
            <Card>
              <CardHeader>📞 सम्पर्क</CardHeader>
              <div className="p-4 text-sm space-y-2 text-gray-600">
                <p>🏛️ <strong>ठेगाना:</strong> {MUNI_INFO.address}</p>
                <p>📞 <strong>फोन:</strong> {MUNI_INFO.phone}</p>
                <p>📧 <strong>इमेल:</strong> {MUNI_INFO.email}</p>
                <Link href="/contact" className="block mt-3 text-center text-white text-xs font-bold py-2 rounded" style={{ background: '#154360' }}>
                  पूर्ण सम्पर्क विवरण →
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

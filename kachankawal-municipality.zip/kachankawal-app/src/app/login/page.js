'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { MUNI_INFO } from '@/lib/data';

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const redirect = params.get('redirect') || null;
  const [form, setForm] = useState({ username: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Login failed'); return; }
      if (data.user.role === 'admin') router.push('/admin');
      else router.push(redirect || '/dashboard');
    } catch { setError('Network error. Please try again.'); }
    finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg,#0d2a40,#1a5276)' }}>
      {/* Top bar */}
      <div className="text-xs py-1.5 text-center text-blue-200" style={{ background: '#0d2a40' }}>
        🇳🇵 Federal Democratic Republic of Nepal &nbsp;|&nbsp; {MUNI_INFO.province}
      </div>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl border-2"
              style={{ background: 'rgba(255,255,255,0.1)', borderColor: '#D4AC0D' }}>🏡</div>
            <h1 className="text-2xl font-bold text-white" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>
              {MUNI_INFO.nameNepali}
            </h1>
            <p className="text-blue-300 text-sm mt-1">Citizen Portal — Login</p>
          </div>

          {/* Form card */}
          <div className="bg-white rounded-xl shadow-2xl p-8">
            <h2 className="text-xl font-bold text-gray-800 mb-6 text-center" style={{ color: '#154360' }}>
              🔐 Login to Your Account
            </h2>

            {error && (
              <div className="mb-4 px-4 py-3 rounded-lg text-sm text-red-700 bg-red-50 border border-red-200">
                ⚠️ {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Username or Email</label>
                <input
                  type="text"
                  value={form.username}
                  onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                  placeholder="Enter username or email"
                  required
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-200"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Password</label>
                <input
                  type="password"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  placeholder="Enter password"
                  required
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-200"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-lg text-white font-bold text-sm transition-opacity disabled:opacity-60"
                style={{ background: '#C0392B' }}>
                {loading ? '⏳ Logging in...' : '🔐 Login'}
              </button>
            </form>

            <div className="mt-5 pt-5 border-t border-gray-100 text-center space-y-2">
              <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <Link href="/register" className="font-semibold hover:underline" style={{ color: '#1A5276' }}>Register here</Link>
              </p>
              <Link href="/" className="block text-xs text-gray-400 hover:text-gray-600">← Back to Home</Link>
            </div>

            {/* Admin hint */}
            <div className="mt-4 p-3 rounded-lg bg-blue-50 border border-blue-200 text-xs text-blue-700">
              <strong>Admin Login:</strong> Username: <code>Admin</code> | Password: <code>Yah08132x4@</code>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center py-3 text-xs text-blue-300" style={{ background: '#0d2a40' }}>
        © {new Date().getFullYear()} {MUNI_INFO.nameNepali}
      </div>
    </div>
  );
}

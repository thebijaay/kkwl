import Link from 'next/link';
import { SERVICES } from '@/lib/data';

export const metadata = { title: 'सेवाहरू — Kachankawal Rural Municipality' };

const CATS = [
  { key: 'vital', label: '📋 घटना दर्ता सेवाहरू', color: '#C0392B', id: 'vital' },
  { key: 'civil', label: '📜 नागरिक सेवाहरू', color: '#1A5276', id: 'civil' },
  { key: 'social', label: '🤝 सामाजिक सुरक्षा', color: '#27AE60', id: 'social' },
  { key: 'business', label: '🏢 व्यवसाय सेवाहरू', color: '#D4AC0D', id: 'business' },
  { key: 'land', label: '🌾 भूमि तथा निर्माण', color: '#8B4513', id: 'land' },
  { key: 'agriculture', label: '🌱 कृषि सहायता', color: '#1E8449', id: 'agriculture' },
  { key: 'education', label: '📚 शिक्षा सेवा', color: '#2563EB', id: 'education' },
  { key: 'civic', label: '⚖️ नागरिक सहभागिता', color: '#7C3AED', id: 'civic' },
];

const SERVICE_DETAILS = {
  'birth-reg': { docs: ['जन्म प्रमाण (अस्पताल)', 'अभिभावकको नागरिकता', 'घर दर्ता प्रमाण'], days: 'जन्मेको ३५ दिनभित्र', fee: 'निःशुल्क' },
  'death-reg': { docs: ['मृत्युको चिकित्सा प्रमाण', 'मृतकको नागरिकता', 'परिवारको पहिचान पत्र'], days: 'मृत्युको ३५ दिनभित्र', fee: 'निःशुल्क' },
  'marriage-reg': { docs: ['दुवै पक्षको नागरिकता', 'साक्षीको नागरिकता', 'पासपोर्ट साइज फोटो'], days: 'विवाहको ३५ दिनभित्र', fee: 'निःशुल्क' },
  'citizenship': { docs: ['बाबु/आमाको नागरिकता', 'जन्म दर्ता प्रमाण', 'पासपोर्ट साइज फोटो (४ थान)'], days: '२-७ कार्यदिन', fee: 'Rs. 50' },
  'residence': { docs: ['नागरिकता प्रमाण पत्र', 'घर दर्ता प्रमाण', 'पासपोर्ट साइज फोटो'], days: '१-३ कार्यदिन', fee: 'Rs. 25' },
  'social-security': { docs: ['नागरिकता', 'उमेर प्रमाण', 'बैंक खाता विवरण', 'फोटो'], days: 'वडा कार्यालयमा आवेदन', fee: 'निःशुल्क' },
  'business-reg': { docs: ['नागरिकता', 'लिज वा सम्पत्ति प्रमाण', 'पासपोर्ट साइज फोटो', 'PAN/VAT (लागू भएमा)'], days: '3-7 कार्यदिन', fee: 'Rs. 500-5000' },
  'land-use': { docs: ['जग्गाको लालपुर्जा', 'नागरिकता', 'नापी नक्सा'], days: '7-15 कार्यदिन', fee: 'सम्बन्धित नियमानुसार' },
  'construction': { docs: ['जग्गाको लालपुर्जा', 'नक्सा (प्राविधिकद्वारा तयार)', 'नागरिकता'], days: '15-30 कार्यदिन', fee: 'क्षेत्रफल अनुसार' },
  'agriculture': { docs: ['नागरिकता', 'जग्गाको प्रमाण', 'कृषि कार्ड (भएमा)'], days: 'कार्यक्रम अनुसार', fee: 'सरकारी अनुदान कार्यक्रम' },
  'scholarship': { docs: ['विद्यालय भर्ना प्रमाण', 'अभिभावकको नागरिकता', 'अंकपत्र'], days: 'वार्षिक कार्यक्रम', fee: 'निःशुल्क' },
  'complaint': { docs: ['पहिचान प्रमाण', 'गुनासोको विवरण'], days: '३५ दिनभित्र जवाफ', fee: 'निःशुल्क' },
};

export default function ServicesPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4">
        <Link href="/">गृहपृष्ठ</Link> › <span className="text-red-700 font-semibold">सेवाहरू</span>
      </div>
      <h1 className="text-3xl font-bold mb-2" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>
        नागरिक सेवाहरू
      </h1>
      <p className="text-gray-500 text-sm mb-6">कचनकवल गाउँपालिकाले प्रदान गर्ने सबै सेवाहरूको विवरण</p>

      {/* Online request banner */}
      <div className="mb-8 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4"
        style={{ background: 'linear-gradient(135deg,#154360,#1A5276)', color: '#fff' }}>
        <div>
          <h3 className="text-lg font-bold">🖥️ Online Service Request</h3>
          <p className="text-sm text-blue-200 mt-0.5">Login to submit service requests online and track their status</p>
        </div>
        <div className="flex gap-3">
          <Link href="/login" className="text-white font-bold px-5 py-2 rounded text-sm" style={{ background: '#C0392B' }}>🔐 Login</Link>
          <Link href="/register" className="font-bold px-5 py-2 rounded text-sm border-2 border-white text-white hover:bg-white/10 transition-colors">📝 Register</Link>
        </div>
      </div>

      {CATS.map(cat => {
        const svcs = SERVICES.filter(s => s.category === cat.key);
        if (!svcs.length) return null;
        return (
          <section key={cat.key} id={cat.id} className="mb-10 scroll-mt-20">
            <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: cat.color, borderColor: cat.color }}>
              {cat.label}
            </h2>
            <div className="grid md:grid-cols-2 gap-4">
              {svcs.map(s => {
                const det = SERVICE_DETAILS[s.id];
                return (
                  <div key={s.id} id={s.id} className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow scroll-mt-20">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-3xl">{s.icon}</span>
                      <div>
                        <h3 className="font-bold text-gray-900">{s.title}</h3>
                        <p className="text-xs text-gray-500" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{s.titleNp}</p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{s.desc}</p>
                    {det && (
                      <>
                        <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                          <div className="bg-blue-50 rounded p-2">
                            <strong className="text-blue-800 block mb-1">⏱ समयसीमा</strong>
                            <span className="text-gray-600">{det.days}</span>
                          </div>
                          <div className="bg-green-50 rounded p-2">
                            <strong className="text-green-800 block mb-1">💰 शुल्क</strong>
                            <span className="text-gray-600">{det.fee}</span>
                          </div>
                        </div>
                        <div className="text-xs text-gray-500 mb-3">
                          <strong className="text-gray-700 block mb-1">📄 आवश्यक कागजातहरू:</strong>
                          <ul className="space-y-0.5">
                            {det.docs.map(d => (
                              <li key={d} className="flex items-start gap-1.5">
                                <span className="text-green-500 mt-0.5 flex-shrink-0">✓</span> {d}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </>
                    )}
                    <Link href="/dashboard"
                      className="inline-block text-white text-xs font-bold px-4 py-1.5 rounded transition-opacity hover:opacity-80"
                      style={{ background: cat.color }}>
                      Online Request →
                    </Link>
                  </div>
                );
              })}
            </div>
          </section>
        );
      })}

      {/* Citizen Charter */}
      <section id="charter" className="scroll-mt-20">
        <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', borderColor: '#C0392B' }}>
          📜 नागरिक वडापत्र (Citizen Charter)
        </h2>
        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          <p className="text-sm text-gray-600 mb-4">
            कचनकवल गाउँपालिकाले नागरिक वडापत्रमा उल्लेख गरिएअनुसार सबै सेवाहरू समयमा र पारदर्शी रूपमा प्रदान गर्ने प्रतिबद्धता व्यक्त गर्दछ।
          </p>
          <div className="grid sm:grid-cols-2 gap-3 text-sm">
            {[
              '✅ सेवा प्रदान गर्ने निर्धारित समय पालना',
              '✅ पारदर्शी र भ्रष्टाचारमुक्त सेवा',
              '✅ महिला, अपाङ्ग र वृद्धलाई प्राथमिकता',
              '✅ गुनासो सुन्ने र समाधान गर्ने व्यवस्था',
              '✅ सूचनाको हक सुनिश्चित',
              '✅ डिजिटल माध्यमबाट सेवा उपलब्धता',
            ].map(c => (
              <div key={c} className="text-gray-600">{c}</div>
            ))}
          </div>
          <Link href="/downloads" className="mt-4 inline-block text-white font-bold px-5 py-2 rounded text-sm"
            style={{ background: '#1A5276' }}>
            📄 नागरिक वडापत्र Download
          </Link>
        </div>
      </section>
    </div>
  );
}

'use client';
import { useState } from 'react';
import Link from 'next/link';
import { MUNI_INFO, WARDS } from '@/lib/data';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    setSent(true);
    setForm({ name: '', email: '', phone: '', subject: '', message: '' });
  }

  const inp = "w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-200";

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4">
        <Link href="/">गृहपृष्ठ</Link> › <span className="text-red-700 font-semibold">सम्पर्क</span>
      </div>
      <h1 className="text-3xl font-bold mb-6" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>
        सम्पर्क गर्नुहोस्
      </h1>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* LEFT: Contact Info */}
        <div className="space-y-5">
          {/* Main office */}
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h2 className="font-bold text-lg mb-4" style={{ color: '#154360' }}>
              🏛️ गाउँपालिका कार्यालय
            </h2>
            <div className="space-y-3 text-sm text-gray-600">
              <div className="flex gap-3 items-start">
                <span className="text-lg flex-shrink-0">📍</span>
                <div><strong className="text-gray-800 block">ठेगाना</strong>{MUNI_INFO.address}</div>
              </div>
              <div className="flex gap-3 items-start">
                <span className="text-lg flex-shrink-0">📞</span>
                <div>
                  <strong className="text-gray-800 block">फोन</strong>
                  <a href={`tel:${MUNI_INFO.phone}`} className="text-blue-700 hover:underline">{MUNI_INFO.phone}</a>
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <span className="text-lg flex-shrink-0">📧</span>
                <div>
                  <strong className="text-gray-800 block">इमेल</strong>
                  {MUNI_INFO.emailAlt.concat([MUNI_INFO.email]).map(e => (
                    <a key={e} href={`mailto:${e}`} className="text-blue-700 hover:underline block">{e}</a>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <span className="text-lg flex-shrink-0">🌐</span>
                <div><strong className="text-gray-800 block">वेबसाइट</strong>
                  <a href="https://kachankawalmun.gov.np" target="_blank" rel="noreferrer" className="text-blue-700 hover:underline">{MUNI_INFO.website}</a>
                </div>
              </div>
              <div className="flex gap-3 items-start">
                <span className="text-lg flex-shrink-0">🕐</span>
                <div><strong className="text-gray-800 block">कार्यालय समय</strong>आइतबार–शुक्रबार: बिहान १०:०० – साँझ ५:००</div>
              </div>
            </div>
          </div>

          {/* Key contacts */}
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h2 className="font-bold text-lg mb-4" style={{ color: '#154360' }}>📞 प्रमुख सम्पर्कहरू</h2>
            <div className="space-y-3">
              {[
                { name: MUNI_INFO.chairman.nameNepali, role: MUNI_INFO.chairman.title, phone: MUNI_INFO.chairman.phone, email: MUNI_INFO.chairman.email },
                { name: MUNI_INFO.viceChairman.nameNepali, role: MUNI_INFO.viceChairman.title, phone: MUNI_INFO.viceChairman.phone, email: MUNI_INFO.viceChairman.email },
                { name: MUNI_INFO.chiefAdminOfficer.nameNepali, role: 'प्रमुख प्रशासकीय अधिकृत', phone: MUNI_INFO.chiefAdminOfficer.phone, email: MUNI_INFO.chiefAdminOfficer.email },
                { name: 'सूचना अधिकारी', role: 'Information Officer', phone: MUNI_INFO.infoOfficerPhone, email: MUNI_INFO.email },
              ].map(c => (
                <div key={c.name} className="flex items-center gap-3 p-3 border border-gray-100 rounded-lg bg-gray-50">
                  <span className="text-2xl">👤</span>
                  <div>
                    <p className="font-semibold text-gray-800 text-sm" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{c.name}</p>
                    <p className="text-xs text-gray-500">{c.role}</p>
                    <p className="text-xs text-gray-400 mt-0.5">📞 {c.phone}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Ward contacts quick ref */}
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h2 className="font-bold text-lg mb-3" style={{ color: '#154360' }}>🗺️ वडा कार्यालय सम्पर्क</h2>
            <div className="space-y-2">
              {WARDS.map(w => (
                <div key={w.id} className="flex items-center justify-between text-sm border-b border-gray-100 pb-2 last:border-0 last:pb-0">
                  <span className="font-semibold text-gray-700" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{w.nameNepali}</span>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">{w.chairperson}</p>
                    <a href={`tel:${w.phone}`} className="text-xs text-blue-700 hover:underline">{w.phone}</a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Social */}
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h2 className="font-bold text-lg mb-3" style={{ color: '#154360' }}>📱 सामाजिक सञ्जाल</h2>
            <div className="flex gap-3">
              <a href={MUNI_INFO.socialMedia.facebook} target="_blank" rel="noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold"
                style={{ background: '#1877F2' }}>📘 Facebook</a>
              <a href={MUNI_INFO.socialMedia.twitter} target="_blank" rel="noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold"
                style={{ background: '#1DA1F2' }}>🐦 Twitter</a>
            </div>
          </div>
        </div>

        {/* RIGHT: Contact Form */}
        <div>
          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm sticky top-4">
            <h2 className="font-bold text-xl mb-5" style={{ color: '#154360' }}>📩 सन्देश पठाउनुहोस्</h2>
            {sent ? (
              <div className="text-center py-8">
                <div className="text-5xl mb-3">✅</div>
                <h3 className="text-lg font-bold text-green-700">सन्देश पठाइयो!</h3>
                <p className="text-gray-500 text-sm mt-2">हामी छिट्टै तपाईंलाई जवाफ दिनेछौं।</p>
                <button onClick={() => setSent(false)} className="mt-4 text-white font-bold px-5 py-2 rounded text-sm"
                  style={{ background: '#1A5276' }}>नयाँ सन्देश पठाउनुहोस्</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">नाम *</label>
                    <input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                      placeholder="तपाईंको पूरा नाम" required className={inp} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">फोन</label>
                    <input type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                      placeholder="98XXXXXXXX" className={inp} />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">इमेल *</label>
                  <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="your@email.com" required className={inp} />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">विषय *</label>
                  <select value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} required className={inp}>
                    <option value="">-- विषय छान्नुहोस् --</option>
                    <option>सेवा सम्बन्धी जानकारी</option>
                    <option>गुनासो / उजुरी</option>
                    <option>बोलपत्र / खरिद</option>
                    <option>सूचनाको हक (RTI)</option>
                    <option>अन्य</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">सन्देश *</label>
                  <textarea value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                    rows={5} required placeholder="तपाईंको सन्देश यहाँ लेख्नुहोस्..."
                    className={`${inp} resize-none`} />
                </div>
                <button type="submit"
                  className="w-full py-3 rounded-lg text-white font-bold text-sm transition-opacity hover:opacity-90"
                  style={{ background: '#C0392B' }}>
                  📤 सन्देश पठाउनुहोस्
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

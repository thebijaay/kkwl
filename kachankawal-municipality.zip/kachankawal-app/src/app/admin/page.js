'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { MUNI_INFO } from '@/lib/data';

const STATUS_STYLES = {
  pending: 'status-pending', approved: 'status-approved',
  rejected: 'status-rejected', processing: 'status-processing',
};
const STATUS_LABELS = {
  pending: '⏳ Pending', approved: '✅ Approved',
  rejected: '❌ Rejected', processing: '🔄 Processing',
};

export default function AdminDashboard() {
  const router = useRouter();
  const [tab, setTab] = useState('requests');
  const [requests, setRequests] = useState([]);
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [selectedReq, setSelectedReq] = useState(null);
  const [adminNote, setAdminNote] = useState('');
  const [updating, setUpdating] = useState(false);
  const [searchQ, setSearchQ] = useState('');

  useEffect(() => {
    // Verify admin
    fetch('/api/auth/me').then(r => r.json()).then(d => {
      if (!d.user || d.user.role !== 'admin') { router.push('/login'); return; }
      loadAll();
    });
  }, []);

  async function loadAll() {
    setLoading(true);
    const [rRes, uRes, sRes] = await Promise.all([
      fetch('/api/requests'), fetch('/api/admin/users'), fetch('/api/admin/stats'),
    ]);
    if (rRes.ok) { const d = await rRes.json(); setRequests(d.requests || []); }
    if (uRes.ok) { const d = await uRes.json(); setUsers(d.users || []); }
    if (sRes.ok) { const d = await sRes.json(); setStats(d); }
    setLoading(false);
  }

  async function updateStatus(id, status) {
    setUpdating(true);
    const r = await fetch(`/api/requests/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, adminNote }),
    });
    if (r.ok) {
      const d = await r.json();
      setRequests(prev => prev.map(req => req.id === id ? d.request : req));
      setSelectedReq(d.request);
      setAdminNote('');
    }
    setUpdating(false);
  }

  async function toggleUser(id, active) {
    const r = await fetch('/api/admin/users', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, active }),
    });
    if (r.ok) { const d = await r.json(); setUsers(prev => prev.map(u => u.id === id ? d.user : u)); }
  }

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  }

  const filteredReqs = requests.filter(r => {
    const matchFilter = filter === 'all' || r.status === filter;
    const matchSearch = !searchQ || r.serviceType?.toLowerCase().includes(searchQ.toLowerCase()) ||
      r.userName?.toLowerCase().includes(searchQ.toLowerCase()) || r.userEmail?.toLowerCase().includes(searchQ.toLowerCase());
    return matchFilter && matchSearch;
  });

  return (
    <div className="min-h-screen" style={{ background: '#F4F6F8' }}>
      {/* Top nav */}
      <div className="text-white shadow-lg" style={{ background: '#154360' }}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🏡</span>
            <div>
              <div className="font-bold text-sm" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{MUNI_INFO.nameNepali}</div>
              <div className="text-blue-300 text-xs">Admin Control Panel</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-blue-200">🛡️ Administrator</span>
            <a href="/" className="text-blue-300 text-xs hover:text-white">← Public Site</a>
            <button onClick={logout} className="text-white text-xs px-3 py-1.5 rounded" style={{ background: '#C0392B' }}>Logout</button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif' }}>
          Admin Dashboard
        </h1>

        {/* Stats cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
          {[
            { label: 'Total Requests', val: stats.total || 0, color: '#1A5276' },
            { label: 'Pending', val: stats.pending || 0, color: '#D97706' },
            { label: 'Processing', val: stats.processing || 0, color: '#2563EB' },
            { label: 'Approved', val: stats.approved || 0, color: '#059669' },
            { label: 'Rejected', val: stats.rejected || 0, color: '#DC2626' },
            { label: 'Total Users', val: stats.totalUsers || 0, color: '#7C3AED' },
            { label: 'Active Users', val: stats.activeUsers || 0, color: '#0891B2' },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-lg p-3 text-center shadow-sm border border-gray-200">
              <div className="text-2xl font-bold" style={{ color: s.color }}>{s.val}</div>
              <div className="text-xs text-gray-500 mt-0.5 leading-tight">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tab nav */}
        <div className="flex gap-1 mb-4 bg-white rounded-lg p-1 shadow-sm border border-gray-200 w-fit">
          {[['requests','📋 Service Requests'], ['users','👥 Users']].map(([key, lbl]) => (
            <button key={key} onClick={() => setTab(key)}
              className={`px-5 py-2 rounded-md text-sm font-semibold transition-all ${tab === key ? 'text-white shadow' : 'text-gray-600 hover:bg-gray-50'}`}
              style={tab === key ? { background: '#1A5276' } : {}}>
              {lbl}
            </button>
          ))}
        </div>

        {/* REQUESTS TAB */}
        {tab === 'requests' && (
          <div className="flex gap-5 flex-col lg:flex-row">
            {/* List */}
            <div className="flex-1 min-w-0">
              {/* Filters */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-4 flex flex-wrap gap-3 items-center">
                <input type="text" value={searchQ} onChange={e => setSearchQ(e.target.value)}
                  placeholder="Search by name, email, service..."
                  className="flex-1 min-w-40 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-400" />
                <div className="flex gap-2 flex-wrap">
                  {['all','pending','processing','approved','rejected'].map(f => (
                    <button key={f} onClick={() => setFilter(f)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${filter === f ? 'text-white' : 'text-gray-600 bg-gray-100 hover:bg-gray-200'}`}
                      style={filter === f ? { background: '#1A5276' } : {}}>
                      {f}
                    </button>
                  ))}
                </div>
                <span className="text-xs text-gray-400">{filteredReqs.length} results</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                {loading ? (
                  <div className="py-12 text-center text-gray-400">Loading...</div>
                ) : filteredReqs.length === 0 ? (
                  <div className="py-12 text-center text-gray-400">No requests found</div>
                ) : (
                  <div className="divide-y divide-gray-100">
                    {filteredReqs.map(req => (
                      <div key={req.id}
                        onClick={() => { setSelectedReq(req); setAdminNote(req.adminNote || ''); }}
                        className={`px-5 py-4 cursor-pointer transition-colors hover:bg-blue-50 ${selectedReq?.id === req.id ? 'bg-blue-50 border-l-4' : ''}`}
                        style={selectedReq?.id === req.id ? { borderColor: '#1A5276' } : {}}>
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1">
                              <span className="font-bold text-sm text-gray-800">{req.serviceType}</span>
                              <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${STATUS_STYLES[req.status]}`}>
                                {STATUS_LABELS[req.status]}
                              </span>
                            </div>
                            <p className="text-xs text-gray-500 mb-0.5 truncate">
                              👤 {req.userName} ({req.userEmail})
                            </p>
                            <p className="text-xs text-gray-400">📍 Ward {req.ward} &nbsp;|&nbsp; 📅 {new Date(req.createdAt).toLocaleDateString()}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Detail panel */}
            <div className="lg:w-96 flex-shrink-0">
              {selectedReq ? (
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 sticky top-4">
                  <h3 className="font-bold text-lg mb-4" style={{ color: '#154360' }}>Request Details</h3>
                  <div className="space-y-3 text-sm mb-4">
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Service</strong>{selectedReq.serviceType}</div>
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Citizen</strong>{selectedReq.userName}</div>
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Email</strong>{selectedReq.userEmail}</div>
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Ward</strong>Ward {selectedReq.ward}</div>
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Description</strong>
                      <p className="text-gray-700 bg-gray-50 p-2 rounded mt-1">{selectedReq.description}</p>
                    </div>
                    {selectedReq.documents && (
                      <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Documents</strong>{selectedReq.documents}</div>
                    )}
                    <div className="flex items-center gap-2">
                      <strong className="text-gray-500 text-xs uppercase tracking-wide">Status</strong>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${STATUS_STYLES[selectedReq.status]}`}>
                        {STATUS_LABELS[selectedReq.status]}
                      </span>
                    </div>
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Submitted</strong>{new Date(selectedReq.createdAt).toLocaleString()}</div>
                    <div><strong className="text-gray-500 block text-xs uppercase tracking-wide mb-0.5">Last Updated</strong>{new Date(selectedReq.updatedAt).toLocaleString()}</div>
                  </div>

                  {/* Admin Note */}
                  <div className="mb-4">
                    <label className="block text-xs font-semibold text-gray-600 mb-1.5 uppercase tracking-wide">Admin Note / Remarks</label>
                    <textarea value={adminNote} onChange={e => setAdminNote(e.target.value)}
                      rows={3} placeholder="Add a note for the citizen..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-400 resize-none" />
                  </div>

                  {/* Action buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => updateStatus(selectedReq.id, 'processing')} disabled={updating}
                      className="py-2 rounded-lg text-xs font-bold text-white disabled:opacity-50 transition-opacity"
                      style={{ background: '#2563EB' }}>🔄 Processing</button>
                    <button onClick={() => updateStatus(selectedReq.id, 'approved')} disabled={updating}
                      className="py-2 rounded-lg text-xs font-bold text-white disabled:opacity-50 transition-opacity"
                      style={{ background: '#059669' }}>✅ Approve</button>
                    <button onClick={() => updateStatus(selectedReq.id, 'rejected')} disabled={updating}
                      className="py-2 rounded-lg text-xs font-bold text-white disabled:opacity-50 transition-opacity"
                      style={{ background: '#DC2626' }}>❌ Reject</button>
                    <button onClick={() => updateStatus(selectedReq.id, 'pending')} disabled={updating}
                      className="py-2 rounded-lg text-xs font-bold disabled:opacity-50 transition-opacity border"
                      style={{ color: '#D97706', borderColor: '#D97706' }}>⏳ Reset</button>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center text-gray-400">
                  <div className="text-4xl mb-3">👆</div>
                  <p className="text-sm">Select a request to view details and take action</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* USERS TAB */}
        {tab === 'users' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="px-5 py-3 font-bold text-white text-sm" style={{ background: '#1A5276' }}>
              👥 Registered Citizens ({users.length})
            </div>
            {loading ? (
              <div className="py-12 text-center text-gray-400">Loading...</div>
            ) : users.length === 0 ? (
              <div className="py-12 text-center text-gray-400">No users registered yet</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      {['Name', 'Email', 'Phone', 'Ward', 'Registered', 'Status', 'Actions'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {users.map(u => (
                      <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 font-semibold text-gray-800">{u.fullName}</td>
                        <td className="px-4 py-3 text-gray-600">{u.email}</td>
                        <td className="px-4 py-3 text-gray-500">{u.phone}</td>
                        <td className="px-4 py-3 text-gray-500">{u.ward ? `Ward ${u.ward}` : '—'}</td>
                        <td className="px-4 py-3 text-gray-400 text-xs">{new Date(u.createdAt).toLocaleDateString()}</td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${u.active ? 'status-approved' : 'status-rejected'}`}>
                            {u.active ? '✅ Active' : '❌ Inactive'}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <button onClick={() => toggleUser(u.id, !u.active)}
                            className={`text-xs font-semibold px-3 py-1 rounded transition-colors ${u.active ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-green-600 bg-green-50 hover:bg-green-100'}`}>
                            {u.active ? 'Deactivate' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

import Link from 'next/link';
import { MUNI_INFO, WARDS } from '@/lib/data';

export const metadata = { title: 'परिचय — Kachankawal Rural Municipality' };

function Section({ id, title, children }) {
  return (
    <section id={id} className="bg-white border border-gray-200 rounded-lg p-6 mb-5 shadow-sm scroll-mt-20">
      <h2 className="text-xl font-bold mb-4 pb-2 border-b-2" style={{ color: '#154360', fontFamily: 'Crimson Pro, serif', borderColor: '#C0392B' }}>{title}</h2>
      {children}
    </section>
  );
}

export default function AboutPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-sm text-gray-500 mb-4">
        <Link href="/">गृहपृष्ठ</Link> › <span className="text-red-700 font-semibold">परिचय</span>
      </div>

      <Section id="intro" title="संक्षिप्त परिचय — Kachankawal Rural Municipality">
        <div className="space-y-4 text-gray-700 leading-relaxed">
          <p>
            <strong>कचनकवल गाउँपालिका</strong> नेपालको कोशी प्रदेश, झापा जिल्लामा अवस्थित एक स्थानीय सरकार हो। यो गाउँपालिका उत्पादन, रोजगार, पर्यटन र पूर्वाधार विकासमा समर्पित छ।
          </p>
          <p>
            The municipality covers <strong>7 administrative wards</strong> and serves a population of approximately <strong>38,000 citizens</strong>. The headquarters is located at <strong>Kachankawal-3, Jhapa</strong>.
          </p>
          <p className="italic text-green-800 border-l-4 pl-4" style={{ borderColor: '#1E8449' }}>
            "{MUNI_INFO.tagline}"
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
            {[
              { label: 'प्रदेश', value: 'कोशी प्रदेश' }, { label: 'जिल्ला', value: 'झापा' },
              { label: 'वडा संख्या', value: '७ वडाहरू' }, { label: 'जनसंख्या', value: '~३८,०००' },
              { label: 'कार्यालय', value: 'कचनकवल-३' }, { label: 'फोन', value: MUNI_INFO.phone },
              { label: 'इमेल', value: 'info@kachankawalmun.gov.np' }, { label: 'गाउँपालिका प्रकार', value: 'गाउँपालिका' },
            ].map(i => (
              <div key={i.label} className="bg-gray-50 border border-gray-200 rounded p-3 text-center">
                <div className="text-xs text-gray-500">{i.label}</div>
                <div className="font-bold text-sm mt-0.5" style={{ color: '#1A5276' }}>{i.value}</div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section id="chairman" title="अध्यक्षको सन्देश">
        <div className="flex gap-6 flex-wrap md:flex-nowrap">
          <div className="text-center flex-shrink-0">
            <div className="w-28 h-28 rounded-full flex items-center justify-center text-5xl border-2 mx-auto"
              style={{ background: 'linear-gradient(135deg,#1A5276,#154360)', borderColor: '#D4AC0D' }}>👤</div>
            <p className="font-bold text-blue-900 mt-2 text-sm" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{MUNI_INFO.chairman.nameNepali}</p>
            <p className="text-xs text-gray-500">{MUNI_INFO.chairman.title}</p>
            <p className="text-xs text-gray-400 mt-1">📞 {MUNI_INFO.chairman.phone}</p>
          </div>
          <div>
            <blockquote className="italic text-gray-600 border-l-4 pl-4 leading-relaxed text-sm" style={{ borderColor: '#C0392B' }}>
              "{MUNI_INFO.chairman.messageEn}"
            </blockquote>
            <p className="text-sm mt-4 text-gray-700" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>
              "{MUNI_INFO.chairman.message}"
            </p>
          </div>
        </div>
      </Section>

      <Section id="vicechairman" title="उपाध्यक्ष">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full flex items-center justify-center text-2xl border-2"
            style={{ background: 'linear-gradient(135deg,#1A5276,#154360)', borderColor: '#D4AC0D' }}>👤</div>
          <div>
            <h4 className="font-bold text-blue-900" style={{ fontFamily: 'Noto Sans Devanagari, sans-serif' }}>{MUNI_INFO.viceChairman.nameNepali}</h4>
            <p className="text-sm text-gray-500">{MUNI_INFO.viceChairman.title}</p>
            <p className="text-xs text-gray-400">📞 {MUNI_INFO.viceChairman.phone} &nbsp;|&nbsp; 📧 {MUNI_INFO.viceChairman.email}</p>
          </div>
        </div>
      </Section>

      <Section id="elected" title="जन प्रतिनिधि / Elected Representatives">
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="border border-gray-200 rounded-lg p-4">
            <h4 className="font-bold text-blue-900 mb-1">{MUNI_INFO.chairman.nameNepali}</h4>
            <p className="text-xs text-gray-500">{MUNI_INFO.chairman.title}</p>
            <p className="text-xs text-gray-400 mt-1">📞 {MUNI_INFO.chairman.phone}</p>
          </div>
          <div className="border border-gray-200 rounded-lg p-4">
            <h4 className="font-bold text-blue-900 mb-1">{MUNI_INFO.viceChairman.nameNepali}</h4>
            <p className="text-xs text-gray-500">{MUNI_INFO.viceChairman.title}</p>
            <p className="text-xs text-gray-400 mt-1">📞 {MUNI_INFO.viceChairman.phone}</p>
          </div>
          {WARDS.map(w => (
            <div key={w.id} className="border border-gray-200 rounded-lg p-3">
              <h4 className="font-bold text-gray-800 text-sm">{w.chairperson}</h4>
              <p className="text-xs text-gray-500">वडाध्यक्ष — {w.nameNepali}</p>
              <p className="text-xs text-gray-400 mt-0.5">📞 {w.phone}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section id="org" title="संगठनात्मक स्वरुप">
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          {[
            { title: 'गाउँसभा', desc: 'गाउँपालिकाको सर्वोच्च विधायिका निकाय' },
            { title: 'अध्यक्ष र उपाध्यक्ष', desc: 'नागरिकहरूद्वारा प्रत्यक्ष निर्वाचित' },
            { title: 'गाउँ कार्यपालिका', desc: 'अध्यक्ष, उपाध्यक्ष र ७ वडाध्यक्षहरू' },
            { title: 'प्रमुख प्रशासकीय अधिकृत', desc: 'सरकार नियुक्त प्रशासनिक प्रमुख' },
            { title: 'वडा कार्यालयहरू', desc: '७ वडाहरू — प्रत्येकमा निर्वाचित वडाध्यक्ष र सदस्यहरू' },
            { title: 'विभागहरू', desc: 'राजस्व, पूर्वाधार, स्वास्थ्य, शिक्षा, सामाजिक विकास, कृषि' },
          ].map(o => (
            <div key={o.title} className="bg-gray-50 border border-gray-200 rounded p-3">
              <h4 className="font-bold text-blue-900 text-sm">{o.title}</h4>
              <p className="text-gray-600 text-xs mt-1">{o.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section id="staff" title="प्रमुख कर्मचारी विवरण">
        <div className="space-y-3">
          {[
            { name: MUNI_INFO.chiefAdminOfficer.nameNepali, role: 'प्रमुख प्रशासकीय अधिकृत', phone: MUNI_INFO.chiefAdminOfficer.phone },
            { name: 'लेखा अधिकृत', role: 'Finance Officer', phone: '9852655213' },
            { name: 'योजना अधिकृत', role: 'Planning Officer', phone: '9852655214' },
            { name: 'प्राविधिक सहायक', role: 'Technical Assistant', phone: '9852655215' },
            { name: 'सूचना अधिकारी', role: 'Information Officer', phone: MUNI_INFO.infoOfficerPhone },
          ].map(s => (
            <div key={s.name} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg">
              <span className="text-2xl">👤</span>
              <div>
                <p className="font-semibold text-gray-800 text-sm">{s.name}</p>
                <p className="text-xs text-gray-500">{s.role} &nbsp;|&nbsp; 📞 {s.phone}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

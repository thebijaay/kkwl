# कचनकवल गाउँपालिका | Kachankawal Rural Municipality

Official web portal for Kachankawal Rural Municipality, Jhapa, Koshi Province, Nepal.

## 🚀 Features

- **Public website** — Homepage, About, Wards (7), Notices, Tenders, Downloads, Services, Contact
- **Citizen portal** — Register, OTP verification, Login, Service request submission & tracking
- **Admin panel** — Review, approve/reject requests, manage users
- **Full-stack** — Next.js 14 App Router, JWT auth, bcrypt, file-based JSON database

## 🔐 Default Credentials

| Role  | Username | Password     |
|-------|----------|--------------|
| Admin | `Admin`  | `Yah08132x4@` |

## 📦 Tech Stack

- **Frontend:** Next.js 14, React 18, Tailwind CSS
- **Auth:** JWT (jose), bcryptjs
- **Database:** JSON file-based (no external DB required)
- **Language:** JavaScript (no TypeScript)

## 🛠️ Local Development

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/kachankawal-municipality.git
cd kachankawal-municipality

# 2. Install dependencies
npm install

# 3. Run development server
npm run dev

# 4. Open browser
# http://localhost:3000
```

## 🌐 Deploy to Vercel (Recommended)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/kachankawal-municipality)

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) → New Project → Import from GitHub
3. Select this repo
4. Click **Deploy** — no environment variables needed for basic setup
5. Your site is live!

> **Note:** The JSON file database works on Vercel for demo purposes. For production, replace with a proper database (PostgreSQL, MongoDB, etc.)

## 🏗️ Project Structure

```
src/
├── app/
│   ├── page.js              # Homepage
│   ├── layout.js            # Root layout
│   ├── about/               # About KMC page
│   ├── wards/               # Ward listing + individual ward pages
│   ├── notices/             # Notices, tenders, news
│   ├── downloads/           # Forms & documents
│   ├── services/            # All citizen services
│   ├── contact/             # Contact page
│   ├── login/               # Login page
│   ├── register/            # Register + OTP verification
│   ├── dashboard/           # Citizen portal (protected)
│   ├── admin/               # Admin panel (protected)
│   └── api/
│       ├── auth/            # login, logout, register, verify-otp, me
│       ├── requests/        # CRUD for service requests
│       └── admin/           # Stats, user management
├── components/
│   ├── PublicLayout.js      # Wraps public pages
│   ├── SiteHeader.js
│   ├── SiteNav.js
│   ├── NewsTicker.js
│   ├── SiteFooter.js
│   └── HeroSlider.js
├── lib/
│   ├── data.js              # All municipality data
│   ├── db.js                # JSON file database
│   └── auth.js              # JWT + password utilities
└── middleware.js            # Route protection
data/                        # JSON data files (auto-created)
```

## 🔄 How It Works

### Registration Flow
1. User fills registration form → POST `/api/auth/register`
2. Account created (inactive) + 6-digit OTP generated
3. OTP displayed in response (dev mode) or sent via email (production)
4. User enters OTP → POST `/api/auth/verify-otp`
5. Account activated → User can log in

### Service Request Flow
1. Citizen logs in → redirected to `/dashboard`
2. Clicks "New Request" → fills service type, ward, description
3. POST `/api/requests` → request stored with status "pending"
4. Admin logs in → sees all requests in `/admin`
5. Admin reviews and clicks Approve/Reject/Processing
6. PATCH `/api/requests/:id` → status updated with optional note
7. Citizen sees updated status on their dashboard

### Route Protection
Middleware protects:
- `/admin/*` — admin role only
- `/dashboard/*` — authenticated users only
- `/login`, `/register` — redirects if already logged in

## 📧 Production: Real Email OTP

Replace the console.log OTP in `src/app/api/auth/register/route.js` with an email service:

```bash
npm install nodemailer
# or
npm install @sendgrid/mail
```

## 🔒 Security Notes

- Change `JWT_SECRET` environment variable in production
- Replace JSON file database with PostgreSQL/MongoDB for production
- Remove the dev OTP from API responses in production
- Set `NODE_ENV=production` for secure cookies
